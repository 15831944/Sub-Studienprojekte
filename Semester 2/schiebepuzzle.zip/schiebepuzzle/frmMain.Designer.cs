﻿namespace Schiebepuzzle
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BoardFormMenu = new System.Windows.Forms.MainMenu(this.components);
            this.GameMenu = new System.Windows.Forms.MenuItem();
            this.GameNew = new System.Windows.Forms.MenuItem();
            this.GameSolve = new System.Windows.Forms.MenuItem();
            this.GameExit = new System.Windows.Forms.MenuItem();
            this.OptionsMenu = new System.Windows.Forms.MenuItem();
            this.OptionsShowLabels = new System.Windows.Forms.MenuItem();
            this.Options3x3 = new System.Windows.Forms.MenuItem();
            this.Options4x4 = new System.Windows.Forms.MenuItem();
            this.Options5x5 = new System.Windows.Forms.MenuItem();
            this.TileTray = new System.Windows.Forms.Panel();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.SuspendLayout();
            // 
            // BoardFormMenu
            // 
            this.BoardFormMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.GameMenu,
            this.OptionsMenu});
            // 
            // GameMenu
            // 
            this.GameMenu.Index = 0;
            this.GameMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.GameNew,
            this.GameSolve,
            this.GameExit});
            this.GameMenu.Text = "Spiel";
            // 
            // GameNew
            // 
            this.GameNew.Index = 0;
            this.GameNew.Text = "Neu";
            this.GameNew.Click += new System.EventHandler(this.GameNew_Click);
            // 
            // GameSolve
            // 
            this.GameSolve.Index = 1;
            this.GameSolve.Text = "Lösen";
            this.GameSolve.Click += new System.EventHandler(this.GameSolve_Click);
            // 
            // GameExit
            // 
            this.GameExit.Index = 2;
            this.GameExit.Text = "Ende";
            this.GameExit.Click += new System.EventHandler(this.GameExit_Click);
            // 
            // OptionsMenu
            // 
            this.OptionsMenu.Index = 1;
            this.OptionsMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.OptionsShowLabels,
            this.Options3x3,
            this.Options4x4,
            this.Options5x5,
            this.menuItem1});
            this.OptionsMenu.Text = "Optionen";
            // 
            // OptionsShowLabels
            // 
            this.OptionsShowLabels.Index = 0;
            this.OptionsShowLabels.Text = "Zeige Zahlen";
            this.OptionsShowLabels.Click += new System.EventHandler(this.OptionsShowLabels_Click);
            // 
            // Options3x3
            // 
            this.Options3x3.Index = 1;
            this.Options3x3.Text = "3x3";
            this.Options3x3.Click += new System.EventHandler(this.Options3x3_Click);
            // 
            // Options4x4
            // 
            this.Options4x4.Index = 2;
            this.Options4x4.Text = "4x4";
            this.Options4x4.Click += new System.EventHandler(this.Options4x4_Click);
            // 
            // Options5x5
            // 
            this.Options5x5.Index = 3;
            this.Options5x5.Text = "5x5";
            this.Options5x5.Click += new System.EventHandler(this.Options5x5_Click);
            // 
            // TileTray
            // 
            this.TileTray.BackColor = System.Drawing.Color.White;
            this.TileTray.Location = new System.Drawing.Point(0, 0);
            this.TileTray.Name = "TileTray";
            this.TileTray.Size = new System.Drawing.Size(240, 270);
            this.TileTray.TabIndex = 0;
            // 
            // menuItem1
            // 
            this.menuItem1.Index = 4;
            this.menuItem1.Text = "Bild";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // frmMain
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(240, 270);
            this.Controls.Add(this.TileTray);
            this.Menu = this.BoardFormMenu;
            this.Name = "frmMain";
            this.Text = "Puzzle";
            this.Resize += new System.EventHandler(this.BoardForm_Resize);
            this.ResumeLayout(false);

        }
		
		
        private System.Windows.Forms.MainMenu BoardFormMenu;
        private System.Windows.Forms.MenuItem GameMenu;
        private System.Windows.Forms.MenuItem GameNew;
        private System.Windows.Forms.MenuItem GameSolve;
        private System.Windows.Forms.MenuItem GameExit;
        private System.Windows.Forms.MenuItem OptionsShowLabels;
        private System.Windows.Forms.MenuItem Options3x3;
        private System.Windows.Forms.MenuItem Options4x4;
        private System.Windows.Forms.MenuItem Options5x5;
        private System.Windows.Forms.MenuItem OptionsMenu;
		
		/// <summary>
        /// Tray to hold game tiles.
        /// </summary>
        private System.Windows.Forms.Panel TileTray;


        #endregion

        private System.Windows.Forms.MenuItem menuItem1;
    }
}