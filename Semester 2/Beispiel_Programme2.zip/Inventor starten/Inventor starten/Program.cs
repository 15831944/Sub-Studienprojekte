using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace Inventor_starten
{
    class Program
    {
        [STAThread] //Single Threaded Apartment - nur ein Proze� dieses Typs erlaubt
        static void Main(string[] args)
        {
            Console.Title = "Inventor starten";
            Type inventorAppType = System.Type.GetTypeFromProgID("Inventor.Application");
            Inventor.Application inv = null;
            try
            {
                //Versuch, mit laufendem Inventor zu verbinden...
                inv = (Inventor.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Inventor.Application");
                Console.WriteLine("Laufender Inventor-Proze� verbunden!"); 
            }
            catch (Exception )
            {
                Console.WriteLine("Inventor l�uft nicht, es wird versucht, Inventor zu starten!");
                try
                {
                    inv = (Inventor.Application)System.Activator.CreateInstance(inventorAppType);
                    Console.WriteLine("Inventor erfolgreich gestartet!");
                }
                catch (Exception )
                {
                    Console.WriteLine("Inventor konnte nicht gestartet werden, Programm wird beendet!");
                    Environment.Exit(1); 
                }
            }
  
            inv.Visible = true;
            //Neue Einzelteildatei mit Vorlage �ffnen
            Inventor.PartDocument mm_doc = (Inventor.PartDocument)inv.Documents.Add(Inventor.DocumentTypeEnum.kPartDocumentObject);
            //Neue Skizze anlegen, Einheiten in mm!!
            mm_doc.UnitsOfMeasure.LengthUnits = Inventor.UnitsTypeEnum.kMillimeterLengthUnits;
            //Skizze auf XY-Ebene erzeugen
            Inventor.PlanarSketch mm_sketch = mm_doc.ComponentDefinition.Sketches.Add(mm_doc.ComponentDefinition.WorkPlanes[3], false);
            //Punkt f�r Skizze erzeugen (in cm!!!, obwohl Dokument auf mm eingestellt wurde!)
            Inventor.Point2d mm_pkt = inv.TransientGeometry.CreatePoint2d(0.5, 0.2);
            Inventor.Point2d mm_pkt2 = inv.TransientGeometry.CreatePoint2d(1.5, 1.2);
            //Kreis in Skizze anlegen...
            Inventor.SketchCircle mm_cir = mm_sketch.SketchCircles.AddByCenterRadius(mm_pkt, 0.7);
            mm_sketch.DimensionConstraints.AddDiameter((Inventor.SketchEntity)mm_cir, mm_pkt2);
            mm_doc.Update();
            
            foreach (Inventor.PropertySet mm_ps in mm_doc.PropertySets)
            {
                Console.WriteLine(mm_ps.Name + " hat " + mm_ps.Count + " Elemente");
                foreach (Inventor.Property mm_prop in mm_ps)
                {
                    try
                    {
                        Console.WriteLine(mm_prop.Name + " hat den Wert: " + (mm_prop.Value == null ? "" : mm_prop.Value.ToString()));
                    }
                    catch
                    {
                        Console.WriteLine(mm_prop.Name + " Wert ist nicht ausgebbar!");
                    }
                }
            }

            Console.WriteLine(mm_doc.Materials.Count + " Materialien gefunden");
            foreach (Inventor.Material mm_mat in mm_doc.Materials)
            {
                Console.WriteLine(mm_mat.Name);
            }


            
            //Ein Profil aus der Skizze holen - es gibt nur eines
            Inventor.Profile mm_pro = mm_sketch.Profiles.AddForSolid();
            //Extrusion in cm!!!
            mm_doc.ComponentDefinition.Features.ExtrudeFeatures.AddByDistanceExtent(mm_pro, 10, Inventor.PartFeatureExtentDirectionEnum.kPositiveExtentDirection, Inventor.PartFeatureOperationEnum.kJoinOperation);

            Console.ReadKey(); 
        }
    }
}
