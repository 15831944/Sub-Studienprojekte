using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Textdateien_schreiben
{
    abstract class myTest
    {
        public static void X()
        {
            Console.WriteLine("paule");
        }
    }


    class A
    {
        public B get()
        {
            return new B();
        }
    }
    class B
    {
        public A get()
        {
            return new A();
        }
    }

    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            myTest.X();
            // Dateiname zusammensetzen, startpath ist Pfad der Anwendung selber
            string mm_fileName = Path.Combine(Application.StartupPath, "datei.txt");
            FileStream mm_fs = new FileStream(mm_fileName, 
                /* �ffnen oder Anlegen - Datei wird immer gefunden */ FileMode.OpenOrCreate,
                /* Datei zum Lesen �ffnen */ FileAccess.Read , 
                /* Andere d�rfen jetzt nicht an die Datei ran */ FileShare.None);
            //StreamReader aus FileStream erstellen..
            StreamReader mm_sr = new StreamReader(mm_fs);
            //Eine Zeile Einlesen
            string mm_line = mm_sr.ReadLine();

            
            Console.Title = "Textdateien schreiben";

            // Dateiname zusammensetzen, startpath ist Pfad der Anwendung selber
            //string mm_fileName = Path.Combine(Application.StartupPath, "datei.txt");

            //Variable f�r Antwort auf Nachfrage...
            DialogResult mm_ant = DialogResult.Yes;

            if (File.Exists(mm_fileName)) // Ist die Datei bereits vorhanden???
            {                             // wenn ja, dann nachfragen, ob �berschrieben werden soll
                mm_ant = MessageBox.Show(mm_fileName + "ist bereits vorhanden.\r\n\r\n" +
                   "Soll die Datei �berschrieben werden?", Application.ProductName,
                    /* Messagebox mit Ja-Nein-Schaltfl�chen */ MessageBoxButtons.YesNo,
                    /* Icon in der MessageBox */               MessageBoxIcon.Question);
            }

            if (DialogResult.Yes == mm_ant) //Wenn nicht mit nein abgebrochen wurde...
            {
                StreamWriter mm_streamwriter = null; //Streamwriter Variable definieren
                try
                {
                    //StreamWriter-Instanz f�r die Datei erzeugen
                    mm_streamwriter = new StreamWriter(mm_fileName, /* append */ false, 
                        /*Kodierung der Datei*/ Encoding.GetEncoding("windows-1252"));
                    // Datei zeilenweise schreiben
                    mm_streamwriter.WriteLine("Zeile 1: Hallo");
                    mm_streamwriter.WriteLine("Zeile 2: Welt!");
                    // StreamWriter und damit auch Datei schlie�en
                    mm_streamwriter.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Fehler beim �ffnen, Schreiben oder Schlie�en der Datei '" +
                        mm_fileName + "': " + ex.Message, Application.ProductName, 
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //Bei Fehler Verlassen der Methode
                    return;
                }
            }


            Console.WriteLine("Beenden mit Return");
            Console.ReadLine();
        }
        public void hallo()
        {
            Console.WriteLine("Hallo");
        }
        static public void shallo()
        {
            Console.WriteLine("Hallo");
        }
    }
}

