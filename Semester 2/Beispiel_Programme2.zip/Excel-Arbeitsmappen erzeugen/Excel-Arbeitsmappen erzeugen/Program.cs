using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Runtime.InteropServices;
//using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
//using eapp = Microsoft.Office.Interop.Excel.Application;

namespace Excel_Arbeitsmappen_erzeugen
{
    class Program
    {
        const string ExcelKey = "Excel.Application";

        [STAThread]
        static void Main(string[] args)
        {
            Console.Title = "Excel-Arbeitsmappen erzeugen";

            //Definition des Application-Objektes
            Excel.Application excel = null;

            try
            {
                //Mit laufendem Excel verbinden...
                excel = (Excel.Application)Marshal.GetActiveObject(ExcelKey);
            }
            catch (System.Runtime.InteropServices.COMException ex)
            {
                try
                {
                    Console.WriteLine("Excel l�uft nicht, Neustart!\n" + ex.Message);
                    //bei Fehler Excel neu starten
                    //excel = new Excel.ApplicationClass();
                    /* 
                     * Wenn f�r ActiveX-Anwendung keine ApplicationClass existiert, anderen Startproze� verwenden
                     */
                    Type excelType = System.Type.GetTypeFromProgID(ExcelKey);
                    excel = (Excel.Application)System.Activator.CreateInstance(excelType);
                }
                catch
                {
                    MessageBox.Show("Excel konnte nicht gestartet werden!");
                    return;
                }
            }
            catch
            {
                MessageBox.Show("Anderer Fehler aufgetreten!");
                return;
            }

            //Wo liegt der Windows-Ordner?
            string winfolder = Environment.GetFolderPath(Environment.SpecialFolder.Windows);

            excel.Visible = true;

            // Arbeitsmappe ohne Vorlage erzeugen 
            // Fehlende Angaben - optionale Default-Parameter gab es nicht in C# vor 2008, daher Kunstgriff f�r Com verwenden
            // object fehlenderParameter  = Missing.Value;
            int openwb = excel.Workbooks.Count;
            Excel.Workbook workbook ;
            if (openwb == 0)
            {
                workbook = excel.Workbooks.Add();
            }
            else
            {
                workbook = excel.ActiveWorkbook;
            }

            // Das aktive Workbook referenzieren ginge so...
            //Excel.Workbook workbook = excel.ActiveWorkbook;

            // Arbeitsblatt erzeugen
            if (workbook.Worksheets.Count == 0)
            {
                workbook.Worksheets.Add();
            }

            // Das erste Arbeitsblatt referenzieren und umbenennen
            Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Worksheets[1];
            Excel.Range mm_cell = (Excel.Range) worksheet.Cells[2, 2];
            if (mm_cell.Value != null)
            {
                //MessageBox.Show(mm_cell.Value.ToString());
            }
            worksheet.Name = "Einkommensberechnung";

            // Die Zelle A1 referenzieren, beschreiben und die Schriftart definieren
            Excel.Range range = worksheet.get_Range("A1");
            range.set_Value(value:"Einkommens-Berechnung");
            // Alternative range.Value2 = "Einkommens-Berechnung";
            range.Font.Size = 16;
            range.Font.Bold = true;

            // A2 bis A5 beschreiben
            worksheet.get_Range("A2").Value2 = "2006";
            worksheet.get_Range("A3").Value2 = "2007";
            worksheet.get_Range("A4").Value2 = "2008";
            worksheet.get_Range("A5").Value2 = "2009";

            // B2 bis B5 in einer Schleife beschreiben
            double[] sales = { 120000, 118000, 130000, 150000 };
            for (int i = 0; i < 4; i++)
            {
                int row = i + 2;
                int col = 2;
                worksheet.Cells[row, col] = sales[i];
                Excel.Range rg = (Excel.Range)worksheet.Cells[7, 4];
                 
            }

            // Eine Formel in die Zelle B6 schreiben und die Zelle fett formatieren
            worksheet.get_Range("B6").FormulaLocal = "=SUMME(B2:B5)";
            //worksheet.Cells[6, 2] = "'=SUMME(B2:B5)";
            // Alternative: Z1S1-Bezugssystem:
            // worksheet.get_Range("B6", fehlenderParameter).FormulaR1C1Local = "=SUMME(Z(-4)S:Z(-1)S)";
            worksheet.get_Range("B6").Font.Bold = true;

            if (worksheet.get_Range("A2").Value.GetType() == typeof(Double))
            {
                double mm_wert = (double)worksheet.get_Range("A2").Value;
            }

            //FileInfo mm_fi = new System.IO.FileInfo("");

            Console.WriteLine("Beenden mit Return");
            Console.ReadLine();
        }
    }
}
