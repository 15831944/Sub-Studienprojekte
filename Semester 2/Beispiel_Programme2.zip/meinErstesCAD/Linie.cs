﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace meinErstesCAD
{
    public class Linie : Kurve
    {
        public Punkt Startpunkt;
        public Punkt Endpunkt;

        public Linie()
        {
            this.Startpunkt = new Punkt();
            this.Endpunkt = new Punkt();
        }

        public Linie(double x_startpunkt, double y_startpunkt, double x_endpunkt, double y_endpunkt)
            : this()
        {
            this.Endpunkt.X = x_endpunkt;
            this.Endpunkt.Y = y_endpunkt;
            this.Startpunkt.X = x_startpunkt;
            this.Startpunkt.Y = y_startpunkt;
        }

        public override void ZeichneDich(Graphics g)
        {
          
            Point sp = new Point((int) Startpunkt.X, (int) Startpunkt.Y);
            Point ep = new Point((int) Endpunkt.X, (int) Endpunkt.Y);
            g.DrawLine(m_pen, sp, ep);
        }
    }
}
