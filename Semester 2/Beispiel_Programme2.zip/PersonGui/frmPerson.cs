﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PersonGui
{
  public partial class frmPerson : Form
  {
    Person mm_new;

    public frmPerson()
    {
      InitializeComponent();
      //Person-Objekt erstellen
      this.mm_new = new Person();
    }


    private void btnOk_Click(object sender, EventArgs e)
    {
      //Werte aus den Steuerelementen holen
      this.mm_new.Vorname = tbVorname.Text.ToString();
      this.mm_new.Name = tbName.Text.ToString();
      this.mm_new.GeburtsDatum = dtpGeburtstag.Value;

      //Person in Messagebox anzeigen
      this.mm_new.showPerson();
    }

    private void btnAbbrechen_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void dtpGeburtstag_ValueChanged(object sender, EventArgs e)
    {
      //Neues Datum setzen
      this.mm_new.GeburtsDatum = dtpGeburtstag.Value;
      //... und Label aktualisieren
      this.lblAlterInTagen.Text = "Du bist " + this.mm_new.GibMirDeinAlterInTagen() + " Tage alt!";
    }


  }
}
