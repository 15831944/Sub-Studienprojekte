/* The Nim game graphics software written by Volynsky Alex ,2005.
 * 
 * The following code demonstrates drawing pictures on a form at run time. 
 * Lets move and do some Image drawing and some mouse click processing.
 * There is only one type of user inputs to Windows(the Mouse).
 * The below program paints the Form with backgraund image and with heaps of pencils, 
 * when it comes up. 
 * 
 * This is a source code, that you can modify to suite your needs.
 * People will be able to improve/modify the source code to accomplish tasks/needs 
 * of their own.(The basic idea behind almost all open source,of course).
 * I know that some people have written Nim-like code and functions for their own project,
 * I'm hoping that we can stop re-inventing wheels.
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Drawing.Drawing2D;


namespace prjNim
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : Form
	{
		#region Prototype all members 

		private MainMenu mainMenu1;
		private MenuItem mnuExit;
		private MenuItem mnuNewGame;
		private System.ComponentModel.IContainer components;
		
		private int xPrevTop = 200, yPrevTop = 672, xCurrentTop , yCurrentTop ,xSize, ySize  ;
		private int positionY;
		private float angle = 0;
		private float delta = 0;
        
		private Boolean rubber_rect_flag = false;
		private Point	FirstPoint ;
		private Point   SecondPoint;
		
                private int num_choos_pens,index_clmn;

		private int posX,posY,posDown;
		private  enum ColorsPen {Gray=0,Blue=1,Red=2};
		private ColorsPen flag_colors=ColorsPen.Gray;
		
		private Region myRegion;

		//Members for setting resolution
		private int isHeight=0,isWidth=0;

		//Member for checking how to create columns
		private int numberOfColumns = 7;
		private int old_numberOfColumns=7 ;   
		private int activeItem=7;

		private Region commonRegion = new Region();
		private GraphicsPath path= new GraphicsPath();

		private int SumOfImages;
		
		private Bitmap[][] images;   // Bitmap Jagged Arrays

		private int[] numberLoadImages={0,0,0,0,0,0,0,0}; // Integers Array
		private int[] Xposition={75,197,317,437,557,677,797,917};   // Integers Array
		
		private int[,] arrPositionX = new int[8,30];
		private int[,] arrPositionY = new int[8,30];

		private int current_column=-1;
		private int current_element_in_column=-1;
			
		private MenuItem mnuColumns;
		private MenuItem menuItem1;
		private MenuItem menuItem2;
		private MenuItem menuItem3;
		private MenuItem menuItem4;
		private MenuItem menuItem5;
		private MenuItem menuItem6;
		private MenuItem menuItem7; 

		private Bitmap PictureBitmap ;
		private Bitmap bitmapGray;
		private Bitmap bitmapRed ;
		private Bitmap bitmapBlue;
		private Bitmap tempImage ;//Empty bitmap
		private Bitmap bitmapBlueSharper;
		private Timer timer1;
		private Timer timer2;
		private Bitmap bitmapRedSharper;

		#endregion

		#region Different Functions   
        
		  /*****************************************************************************/
		 /* The method checks your resources                                          */
		/*****************************************************************************/
		private bool Check_Resource()
		{  
			//Check  if connected mouse - device
			if(SystemInformation.MousePresent!=true)
			{
				MessageBox.Show("This program can not work without mouse.You must connect this device.","Not mouse");
				return false;
			}

			string [] files_Dir = {"Autumn.jpg","Pen_Gray.bmp","Pen_Blue.bmp","Pen_Red.bmp",
									  "Blue_Sharper.bmp","Red_Sharper.bmp"};

			// Check existing files
			foreach (string i_File in files_Dir) 
			{
				FileInfo fi = new FileInfo(Path.Combine(Application.StartupPath, i_File));
				// figure out if the file exists or not
				if (fi.Exists!=true)
				{
					MessageBox.Show("The file "+ i_File + " does not exist in the specified directory","Can not find file...");
					return false;
				}       
			}

			return true;
		}

		  /*****************************************************************************/
		 /* The method creates six images and also saves location of every pencil     */                                            
		/*****************************************************************************/
		private void FirstMyInitialize() 
		{
			PictureBitmap = new Bitmap(Path.Combine(Application.StartupPath, "Autumn.jpg"));
			bitmapGray = new Bitmap(Path.Combine(Application.StartupPath, "Pen_Gray.bmp"));
			bitmapRed = new Bitmap(Path.Combine(Application.StartupPath, "Pen_Red.bmp"));
			bitmapBlue = new Bitmap(Path.Combine(Application.StartupPath, "Pen_Blue.bmp"));

			bitmapBlueSharper = new Bitmap(Path.Combine(Application.StartupPath, "Blue_Sharper.bmp"));
			bitmapRedSharper=new Bitmap(Path.Combine(Application.StartupPath, "Red_Sharper.bmp"));

			tempImage = new Bitmap(bitmapGray.Width, bitmapGray.Height);
			
			int x=-160;
			for(int i=0; i<8; i++,x+=120)
			{
				int y=-18;
				for(int j=0; j<30; j++,y-=18)
				{
					arrPositionX[i,j] = x;
				    arrPositionY[i,j] = y;
				}
			}

			SumOfImages=0;
			xSize = tempImage.Width;
			ySize = tempImage.Height;	
			xCurrentTop =  xPrevTop;
			yCurrentTop = yPrevTop;
			
		}

		  /**********************************************************************************/
		 /* The method creates a matrix in the size 7 on 30 for the pencils                */                                            
		/**********************************************************************************/
		void CreateNew_Images()
		{
			//Allocation of memory for array bitmap
			images = new Bitmap[8][];

			for(int i=0; i<8; i++)
			{
					
				images[i] = new Bitmap [30];
                
				for(int j=0; j<30; j++)
				{
					images[i][j]= new Bitmap(tempImage);//Load empty image
					images[i][j].MakeTransparent(); //Without background
              
				}
			}
		}

		  /*****************************************************************************/
		 /* The method fills the matrix with gray pencils                             */                      
		/*****************************************************************************/
		void Fill_Images()
		{
			int new_number_elements;
			Random rdm;

			for(int i=0; i<numberOfColumns; i++)
			{
				rdm = new Random(unchecked((int)DateTime.Now.Ticks));
				new_number_elements  = rdm.Next(1,30);

				SumOfImages+=new_number_elements;

				for(int j=0; j<new_number_elements; j++)
				{
					images[i][j]= bitmapGray;//
					images[i][j].MakeTransparent(); //Without background
						
				}
				numberLoadImages.SetValue(new_number_elements,i);
				
				System.Threading.Thread.Sleep(35);
			}

			Invalidate();
			
		}

		  /*****************************************************************************/
		 /* The method cleans the matrix using empty image                            */                                            
		/*****************************************************************************/
		void ClearImages()
		{
			for(int i=0; i<8; i++)
			{
				for(int j=0; j<30; j++)
				{
					images[i][j]=tempImage;
				}
			}

			Invalidate();	
		}
		
		  /*****************************************************************************/
		 /* The method generates question                                             */               
		/*****************************************************************************/
		private void Question(string str)
		{
			switch(MessageBox.Show("New Game?","The game is over."+str+" won",MessageBoxButtons.YesNo))
			{
				case DialogResult.Yes: //New Game
						 
					numberOfColumns = activeItem;
					FirstMyInitialize();
					Fill_Images();
					this.Invalidate();
					break;

				case DialogResult.No: //Finish Game
					this.Close(); 
					break;
								
			}
             
		}

		  /*****************************************************************************/
		 /* Computer's game strategy                                                  */                       
		/*****************************************************************************/
		private void ComputerGame()
		{ 
			int tryResultElements=-1;
			int numElements;
			int n;
			int y;
			//////////////////////////////////////////////////////////////////
			// 3 cycles to find column and number elements                  //
			//////////////////////////////////////////////////////////////////
			
			for(int k=0; k<numberOfColumns && tryResultElements!=0 ; k++)
			{
				numElements=(int)numberLoadImages.GetValue(k);  

				for (n=1; n<=numElements; n++)
				{   
					num_choos_pens=n; 
					index_clmn=k;
					tryResultElements = numElements-n;
					
					for(int m=0; m<numberOfColumns; m++)
					{
						if(k!=m)
							tryResultElements^=numberLoadImages[m];
					}
                        
					if(tryResultElements==0)
					{  
						num_choos_pens=n;
						index_clmn=k;
						break;
					}
				}
					
			}
             
			 
             
			/////// Let's paint red color pencil(s)
			///
			current_element_in_column = ((int)numberLoadImages.GetValue(index_clmn));
			current_column = index_clmn;

			y= (int)numberLoadImages.GetValue(index_clmn)-1;
			for(int x=0; x<num_choos_pens; x++,y--)
			{
				images[index_clmn][y]=this.bitmapRed;
				images[index_clmn][y].MakeTransparent(Color.White);
			}
			
			flag_colors=ColorsPen.Red;
			Invalidate();
             
			//Set value of members for deleting all pencils
			angle=0;
			posX=this.arrPositionX[current_column,current_element_in_column];
			posY=this.arrPositionY[current_column,current_element_in_column];	
			current_element_in_column-=1;
			delta=1;
			posDown=-16;
							
			//this.Enabled=false;
			this.timer2.Start();
		}
 
		   /**********************************************************************************/                
           /*The method takes the p1 and p2 coordinates of the starting and ending points and*/ 
           /*convert and normalize the points and draw the reversible frame(rubber rectangle)*/ 
	       /**********************************************************************************/
		
                private void MyDrawReversibleRectangle( Point p1, Point p2 )
		{
            // Convert the points to screen coordinates.
			p1 = PointToScreen( p1 );
			p2 = PointToScreen( p2 );
	
			Rectangle rc = new Rectangle(p1.X, p1.Y, p2.X - p1.X, p2.Y - p1.Y);
                        
            // Draw the reversible frame.
			ControlPaint.DrawReversibleFrame( rc, Color.Black, FrameStyle.Thick );
		}

		#endregion

		#region   Constructor/Destructor

		  /**********************************************************************************/
		 /* The method creates and initializes the main form                               */                  
		/**********************************************************************************/
		public Form1()
		{ 
			if(false==Check_Resource())
			{
				this.Tag="0";
				return;
			}
			else
				this.Tag="1";

			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!//
			//  You can use next section of a code (four lines for set resolution of client)  // 
			//  only if you have permission on your machine.                                 //
			//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!//

			  Screen Srn=Screen.PrimaryScreen;
			  isHeight=Srn.Bounds.Width;
			  isWidth=Srn.Bounds.Height;

			  Resolution.CResolution ChangeRes=new Resolution.CResolution(isHeight,isWidth);
            
			/////////////////////////////////////////////////////////////////////////////////
			MyInit();

			FirstMyInitialize();
		
			CreateNew_Images();
			Fill_Images();

			
			this.SetStyle( ControlStyles.UserPaint, true ); 
			this.SetStyle( ControlStyles.AllPaintingInWmPaint, true ); 
			this.SetStyle( ControlStyles.DoubleBuffer, true ); 
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Windows Form  code    
		
		  /**********************************************************************************/
		 /* The method creates and initializes the widgets on main form                    */                  
		/**********************************************************************************/
		private void MyInit()
		{
			this.components = new System.ComponentModel.Container();
			this.mainMenu1 = new MainMenu();
			this.mnuExit = new MenuItem();
			this.mnuNewGame = new MenuItem();
			this.mnuColumns = new MenuItem();
			this.menuItem1 = new MenuItem();
			this.menuItem2 = new MenuItem();
			this.menuItem3 = new MenuItem();
			this.menuItem4 = new MenuItem();
			this.menuItem5 = new MenuItem();
			this.menuItem6 = new MenuItem();
			this.menuItem7 = new MenuItem();
			this.timer1 = new Timer(this.components);
			this.timer2 = new Timer(this.components);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new MenuItem[] {
																					  this.mnuExit,
																					  this.mnuNewGame,
																					  this.mnuColumns});
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 0;
			this.mnuExit.Text = "Exit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// mnuNewGame
			// 
			this.mnuNewGame.Index = 1;
			this.mnuNewGame.Text = "New Game";
			this.mnuNewGame.Click += new System.EventHandler(this.mnuNewGame_Click);
			// 
			// mnuColumns
			// 
			this.mnuColumns.Index = 2;
			this.mnuColumns.MenuItems.AddRange(new MenuItem[] {
																					   this.menuItem1,
																					   this.menuItem2,
																					   this.menuItem3,
																					   this.menuItem4,
																					   this.menuItem5,
																					   this.menuItem6,
																					   this.menuItem7});
			this.mnuColumns.Text = "Columns";
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "2";
			this.menuItem1.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "3";
			this.menuItem2.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "4";
			this.menuItem3.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "5";
			this.menuItem4.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 4;
			this.menuItem5.Text = "6";
			this.menuItem5.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// menuItem6
			// 
			this.menuItem6.Checked = true;
			this.menuItem6.Index = 5;
			this.menuItem6.Text = "7";
			this.menuItem6.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 6;
			this.menuItem7.Text = "8";
			this.menuItem7.Click += new System.EventHandler(this.Coosing_Column);
			// 
			// timer1
			// 
			this.timer1.Interval = 3;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// timer2
			// 
			this.timer2.Interval = 3;
			this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(368, 265);
			this.MaximizeBox = false;
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Game Nim  (Screen resolution 1024 by 768 pixels)";
			this.WindowState = FormWindowState.Maximized;
			this.MouseDown += new MouseEventHandler(this.Form1_MouseDown);
			this.Click += new System.EventHandler(this.Form1_Click);
			this.MouseUp += new MouseEventHandler(this.Form1_MouseUp);
			this.MouseMove += new MouseEventHandler(this.Form1_MouseMove);

		}
		#endregion

		#region   Functions Menu        

		  /**********************************************************************************/
		 /* Event of pressing on item Exit in the toolbar of the menu                      */                                            
		/**********************************************************************************/
		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		  /**********************************************************************************/
		 /* Event of pressing on item New Game in the toolbar of the menu                  */                                            
		/**********************************************************************************/
		private void mnuNewGame_Click(object sender, System.EventArgs e)
		{
			SumOfImages=0;

		    posY = 150;
		    Invalidate();
		
            this.timer1.Stop();
			this.timer2.Stop();
            this.flag_colors=ColorsPen.Gray;

            for(int i=0; i<8; i++ )
					numberLoadImages.SetValue(0,i);

			this.ClearImages();
			this.Fill_Images();

          
			
			Invalidate();

			rubber_rect_flag=false;
			 
		}
		  /**********************************************************************************/
		 /* Event item selecting  numbers of columns  in the toolbar of the menu           */                                            
		/**********************************************************************************/
		private void Coosing_Column(object sender, System.EventArgs e)
		{
			menuItem1.Checked=false;
			menuItem2.Checked=false;
			menuItem3.Checked=false;
			menuItem4.Checked=false;
			menuItem5.Checked=false;
			menuItem6.Checked=false;
			menuItem7.Checked=false;

			MenuItem mnu=(MenuItem)sender;
			mnu.Checked=true;

			old_numberOfColumns = numberOfColumns;
			numberOfColumns = Convert.ToInt16(mnu.Text);
			activeItem = numberOfColumns;
		}
		#endregion

		#region Functions Form        
             /**********************************************************************************/
		    /* The OnPaint method also allows derived classes to handle the event             */
		   /* without attaching a delegate. This is the preferred technique for              */
		  /* handling the event in a derived class                                          */    
		 /* One of the most responsible functions in this program!!!!                      */
        /* This function re-draw the image on the main form !!!                           */                                               
	   /**********************************************************************************/
		protected override void OnPaint(PaintEventArgs e) 
		{
			bool flag=false;

			//Output image for background
			e.Graphics.DrawImageUnscaled(PictureBitmap, 0, 0);
           
			//Output a sharper
			if(flag_colors==ColorsPen.Blue)
			{    
				//Output Blue Sharper
				bitmapBlueSharper.MakeTransparent(Color.White);
				e.Graphics.DrawImage(bitmapBlueSharper,((int)Xposition.GetValue(current_column)),0);
				
				
			}
			else if(flag_colors==ColorsPen.Red)
			{
				bitmapRedSharper.MakeTransparent(Color.White);
				e.Graphics.DrawImage(bitmapRedSharper,((int)Xposition.GetValue(current_column)),0);
				
			}

			///Output other pencils  
			int x=-160;

			for(int i=0; i<8; i++,x+=120)
			{
				int y=-18;
				for(int j=0; j<((int)numberLoadImages.GetValue(i)); j++)
				{ 
					    			 		
					if(i==current_column && j==current_element_in_column)//if found pen for rotate 
					{	
						flag=true;						
					}
					else
					{
						if(i==current_column && j>current_element_in_column)
						{
							images[i][j]=this.bitmapGray;
							e.Graphics.DrawImageUnscaled(images[i][j], xCurrentTop+x, yCurrentTop+y+posDown);
							y-=18;
							e.Graphics.ResetTransform();
                           
						}
						else
						{ 

							e.Graphics.DrawImageUnscaled(images[i][j], xCurrentTop+x, yCurrentTop+y);
							y-=18;
							e.Graphics.ResetTransform();
						}
					}
					 		
				}					
								
				yCurrentTop = yPrevTop;					
			}	
								
			///  Rotate the chosen pen  //////
			if(flag)
			{
				positionY=yCurrentTop+posY+images[current_column][current_element_in_column].Height/2;

				//Rotate pen
				e.Graphics.TranslateTransform( xCurrentTop+posX+images[current_column][current_element_in_column].Width/2,positionY); 
					
				e.Graphics.RotateTransform(angle);
				e.Graphics.ScaleTransform(1,(float) delta);

				images[current_column][current_element_in_column].MakeTransparent(Color.White);

				e.Graphics.DrawImage(images[current_column][current_element_in_column],
					new Rectangle(-images[current_column][current_element_in_column].Width,
					-images[current_column][current_element_in_column].Height,
					images[current_column][current_element_in_column].Width,
					images[current_column][current_element_in_column].Height));
                
				//again output sharper (Red/Blue)
				e.Graphics.ResetTransform();
				bitmapBlueSharper.MakeTransparent(Color.White);
				if(flag_colors==ColorsPen.Blue)
					e.Graphics.DrawImage(this.bitmapBlueSharper,((int)Xposition.GetValue(current_column)),0);
                else if(flag_colors==ColorsPen.Red )
					e.Graphics.DrawImage(this.bitmapRedSharper,((int)Xposition.GetValue(current_column)),0);
			}

			//When overriding OnPaint in a derived class, be sure to call the base class's 
			//OnPaint method so that registered delegates receive the event.
			base.OnPaint(e);		
		}
		
		  /**********************************************************************************/
		 /* Event of clicking on main form                                                 */                                            
		/**********************************************************************************/
		private void Form1_Click(object sender, System.EventArgs e)
		{
			if(this.timer1.Enabled==true || this.timer2.Enabled==true)
				return;

			int x=-160;
			int num_elements;
			 
			if(SecondPoint == FirstPoint)
			{
				for(int i=0; i<numberOfColumns; i++,x+=120)
							{
								num_elements=(int)numberLoadImages.GetValue(i);
								int y=-18;

								for(int j=0; j<num_elements; j++,y-=18)
								{
									
									path.AddRectangle(new Rectangle(xCurrentTop+x, yCurrentTop+y,images[i][j].Width,images[i][j].Height));
									myRegion = new Region(path);

									if ( myRegion.IsVisible(FirstPoint)==true)
									{       
										images[i][j]=this.bitmapBlue;

										flag_colors=ColorsPen.Blue;//Set blue

										myRegion.MakeEmpty();
										path.Reset();
											
										angle=0;
										current_column=i;
										current_element_in_column=j;
										posX=x;
										posY=y;	
										delta=1;
										posDown=-16;
											
										this.timer1.Start();
										
										return;
									}		
									myRegion.MakeEmpty();
									path.Reset();
								}
							}

			}
			
		
		}

		  /**********************************************************************************/
		 /* Event of clicking on mouse-device                                              */                  
		/**********************************************************************************/
		private void Form1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
            if(this.timer1.Enabled==true || this.timer2.Enabled==true)
				return;
			
			rubber_rect_flag = true;
            FirstPoint= new Point(e.X,e.Y);
			SecondPoint = FirstPoint;

		}
        
		  /**********************************************************************************/
		 /* Event of moving the mouse-device                                               */                                            
		/**********************************************************************************/
		private void Form1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(this.timer1.Enabled==true || this.timer2.Enabled==true)
				return;
                        
            //  called when the mouse is moved                  
			if( rubber_rect_flag ) // If it is required to draw rubber rectangle
			{
				MyDrawReversibleRectangle( FirstPoint, SecondPoint );
                                
                // Update last point.
				SecondPoint = new Point(e.X,e.Y); 
				MyDrawReversibleRectangle( FirstPoint, SecondPoint );
			}
		}

		  /**********************************************************************************/
		 /* Event of release the mouse-device                                              */                                            
		/**********************************************************************************/
		private void Form1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			int col = -1;

			if(this.timer1.Enabled==true || this.timer2.Enabled==true)
				return;

			SecondPoint = new Point(e.X,e.Y);
			

			if( rubber_rect_flag)
			{
				if(FirstPoint.X!=SecondPoint.X && FirstPoint.Y!=SecondPoint.Y)
				{
					MyDrawReversibleRectangle( FirstPoint, SecondPoint );
					
					//Check region by selected rectangle 
					Rectangle rc  = new Rectangle(FirstPoint.X, FirstPoint.Y,
						                          SecondPoint.X-FirstPoint.X,
												  SecondPoint.Y-FirstPoint.Y);

					if(rc.Width<=images[0][0].Width && rc.Width>0)
					{   
						int a=-160;
						for(int k=0; k<numberOfColumns && col<0 ; k++,a+=120)
						{

							int pX1 = this.PointToScreen(new Point(xCurrentTop+a,0)).X;
							int pX2 = pX1 + images[0][0].Width ;

							    if(this.PointToScreen(FirstPoint).X>=pX1 && this.PointToScreen(SecondPoint).X<=pX2)
								col=k;
						}
						if(col>=0)
						{
							num_choos_pens=0;
                            current_element_in_column =0;

							path.AddRectangle(rc);
							myRegion = new Region(path);

							int num_col=(int)numberLoadImages.GetValue(col);
							
							for(int x=0,y=-18; x <  num_col; x++,y-=18)
							{
								////// Let's change the pencil's color to blue
								///
								if ( myRegion.IsVisible((new Rectangle(xCurrentTop-160+120*col, yCurrentTop+y,images[col][x].Width,images[col][x].Height)))==true)
								{
									images[col][x]=this.bitmapBlue;
									images[col][x].MakeTransparent(Color.White);
									num_choos_pens++;
									if(current_element_in_column < x)current_element_in_column =x;
								}
								
							}
							
							if(num_choos_pens>0)
							{
								flag_colors=ColorsPen.Blue ;
								Invalidate();
             
								//Set value of members for delete all pencils
								current_column =col;
								angle=0;
								posX=this.arrPositionX[current_column,current_element_in_column];
								posY=this.arrPositionY[current_column,current_element_in_column];	
								//current_element_in_column-=1;
								delta=1;
								posDown=-16;
								
								//this.Enabled=false;
								this.timer2.Start();
							}
							
							
						}	
					}
					
				}
				rubber_rect_flag=false;
			}
			
		}
		
		#endregion

		#region Function Timer        
		
		  /**********************************************************************************/
		 /* Timer for blue pencil                                                          */                 
		/**********************************************************************************/
		private void timer1_Tick(object sender, System.EventArgs e)
		{
			if(angle<90)
			{
				angle+=3;
				Invalidate();
				delta+=(float)0.018;
			}
			else
			{
				
				posY-=5;
				if(posDown<0)posDown+=1;
				Invalidate();

				if(positionY <= this.bitmapBlueSharper.Height )
				{  
					numberLoadImages.SetValue((((int)numberLoadImages.GetValue(current_column))-1),current_column);
					images[current_column][current_element_in_column]=this.bitmapGray;
					angle=0;
					current_column =-1;
					current_element_in_column=-1;
					flag_colors=ColorsPen.Gray;
       
					this.timer1.Stop();

					this.rubber_rect_flag=false;

					Invalidate();
					SumOfImages=SumOfImages-1;
					
					if(SumOfImages==0)//if sum of pencils equal to 0
						Question("Blue");
					else //computers step
					{
						ComputerGame();
					}
				}

			}

		
				
		}
		
		  /**********************************************************************************/
		 /* Timer for red pencil                                                           */            
		/**********************************************************************************/
		private void timer2_Tick(object sender, System.EventArgs e)
		{
			if(num_choos_pens>0)
			{

				if(angle<90)
				{
					angle+=3;
					Invalidate();
					delta+=(float)0.018;
					
				}
				else
				{
				
					posY-=5;
					if(posDown<0)posDown+=1;
					Invalidate();

					if(positionY < this.bitmapBlueSharper.Height )
					{  
						numberLoadImages.SetValue((((int)numberLoadImages.GetValue(current_column))-1),current_column);
						
						num_choos_pens= num_choos_pens - 1;
						current_element_in_column=current_element_in_column-1;
                        
						if(current_element_in_column>=0)
						{
							posX=this.arrPositionX[current_column,current_element_in_column];
							posY=this.arrPositionY[current_column,current_element_in_column];	
						}
						
						
						delta=1;
						posDown=-16;
						SumOfImages=SumOfImages-1;
						angle=0;
					}

				}
			}
			else
			{        
				ColorsPen tmp = this.flag_colors;

				this.timer2.Stop();
				this.rubber_rect_flag=false;
				this.flag_colors=ColorsPen.Gray;
				Invalidate();

				if(SumOfImages==0 )//if sum of pencils equal to 0
				{
					switch(tmp)
					{
						case ColorsPen.Red: 
								Question("Red");
							break;

						case ColorsPen.Blue:
								Question("Blue"); 
							break;
								
					}
				}
				else //computers step
				{
					if(current_element_in_column>=0)
					{
						posX=this.arrPositionX[current_column,current_element_in_column]+50;
						posY=this.arrPositionY[current_column,current_element_in_column]+8;
					}
					
					if(tmp==ColorsPen.Red) return;

				  ComputerGame();		     
				}			
			}
		}

		
		#endregion


		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		  /*****************************************************************************/
		 /* The start point of the program                                            */                                            
		/*****************************************************************************/
		[STAThread]
		static void Main() 
		{   
			Form frm = new Form1();
			if(frm.Tag.ToString()=="1") Application.Run(frm);
			else Application.Exit();
		}

		

		
	}

}



