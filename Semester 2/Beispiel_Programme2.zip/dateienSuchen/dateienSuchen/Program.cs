using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Dateisuche
{
    class Dateisuche
    {
        static void Main(string[] args)
        {
            //Eingabeaufforderungen einzeln f�r Laufwerk, Pfad, Dateiname- & Typ
            string Laufwerk, Pfad, Dateiname, Dateityp;
            Console.WriteLine("Auf welchem Laufwerk soll gesucht werden?\n");
            Laufwerk = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Bitte geben Sie den Pfad des Verzeichnisses an, ab dem gesucht werden soll!\n");
            Pfad = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Bitte geben Sie den Namen der gesuchten Datei/Verzeichnis ein:\n");
            Dateiname = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Wenn es sich dabei um eine Datei handelt, geben Sie bitte den Dateityp an:\n");
            Dateityp = Console.ReadLine();
            Console.WriteLine();


            //Hier kommt noch eine �berpr�fung der Eingaben auf Sinnhaftigkeit 

            // Verkn�pfung der Eingaben zu einem Suchpfad
            string Suchpfad, Datei, Suchdatei, Suchverzeichnis;
            Suchpfad = (Laufwerk + ":\\" + Pfad);
            Datei = (Dateiname + "." + Dateityp);
            Suchdatei = (Suchpfad + "\\" + Datei);
            Suchverzeichnis = (Suchpfad + "\\" + Dateiname);
            Console.WriteLine();
            durchsuchePfad(Suchpfad);
        }

        static void durchsuchePfad(string startpfad)
        {
            //Eine neue Instanz "di" der Klasse "Directory-Info wird erzeugt, welche den startpfad repr�sentiert.
            DirectoryInfo di = new DirectoryInfo(startpfad);
            //Wenn der startpfad existiert, untersuchen
            if (di.Exists)
            {
                Console.WriteLine();

                //Die Variablen fia vom Typ FileInfo[] werden alle 
                //Dateien im startpfad als Feld zugewiesen
                FileInfo[] fia = di.GetFiles();

                //Wenn der startpfad existiert, werden alle enthaltenen 
                //Dateien aufgelistet
                Console.WriteLine("Der Suchpfad \"" + startpfad + "\" exisitert und enth�lt folgende Dateien:");
                Console.WriteLine();
                foreach (FileInfo fri in fia)
                    Console.WriteLine(fri.Name);
                //Console.ReadKey(true); //Unterbrechermodus
                Console.WriteLine();

                //Der Variablen dia vom Typ DirevtoryInfo[] werden 
                //alle Unterordner im startpfad als Feld zugewiesen.
                DirectoryInfo[] dia = di.GetDirectories();

                Console.WriteLine();
                //Alle Unterverzeichnisse des Feldes dia durchlaufen
                foreach (DirectoryInfo dri in dia)
                {
                    Console.WriteLine("Der Suchpfad \"" + startpfad + "\" exisitert und enth�lt folgende Ordner:");
                    Console.WriteLine(dri.Name);
                    //... und weiter durchsuchen ... (Rekursion)
                    durchsuchePfad(startpfad + "\\" + dri.Name + "\\");
                }
            }

        }

    }
}

