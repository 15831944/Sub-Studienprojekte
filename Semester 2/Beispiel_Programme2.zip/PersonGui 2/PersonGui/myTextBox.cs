﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace PersonGui
{
  class myTextBox: TextBox
  {
    bool vorgabe = true;
    private string m_vorgabeName;
    public string Vorgabename
    {
      get
      {
        return m_vorgabeName;
      }
      set
      {
        m_vorgabeName = value;
        setVorgabeText();
      }
    }

    public myTextBox()
      : base()
    {
      m_foreColor = this.ForeColor;
    }

    public Color VorgabeFarbe
    {
      get
      {
        return m_vorgabeFarbe;
      }
      set
      {
        m_vorgabeFarbe = value;
      }
    }
    
    private Color m_vorgabeFarbe  = Color.Gray;
    private Color m_foreColor;


    protected override void OnLeave(EventArgs e)
    {
      base.OnLeave(e);
      if ((this.Text.ToString() == "") || (this.Text.ToString() == this.Vorgabename))
      {
        this.Text = this.Vorgabename;
        this.ForeColor = VorgabeFarbe;
      }
      else
      {
        this.ForeColor = m_foreColor;
      }
    }


    private void setVorgabeText()
    {
      if ((base.Text.ToString() == "") || vorgabe)
      {
        base.Text = this.Vorgabename;
        base.ForeColor = this.VorgabeFarbe;
        base.SelectAll();
        vorgabe = true; 
      }
    }

    protected override void OnCreateControl()
    {
      base.OnCreateControl();
      setVorgabeText();
    }

    protected override void OnClick(EventArgs e)
    {
      base.OnClick(e);
      selectOnEntering();
    }

    private void selectOnEntering()
    {
      if (base.Text.ToString() == this.Vorgabename)
      {
        this.Select();
        this.SelectAll();
      }
    }

    protected override void OnEnter(EventArgs e)
    {
      base.OnEnter(e);
      selectOnEntering();
    }

    protected override void OnTextChanged(EventArgs e)
    {
      base.OnTextChanged(e);
      this.ForeColor = m_foreColor;
      vorgabe = false;
    }

    public override string Text
    {
      get
      {
        return (((base.Text == this.Vorgabename) || vorgabe)?"":base.Text);
      }
      set
      {
        base.Text = value;
      }
    }

  }
}
