using System;
using System.Collections.Generic;
using System.Text;

namespace person
{
    class Zufallszahl
    {
        private static Random m_random = new Random();
        //private static Random m_random = new Random(System.Environment.TickCount);

        public static int ErzeugeZahlZwischen(int von, int bis)
        {
            double mm_z = m_random.NextDouble();
            return (int)(Math.Min(von, bis) + Math.Round(Math.Abs(von - bis) * mm_z, 0));
        }
    }

    class Program
    {
        static void Main222(string[] args)
        {
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Zahl {0} ist {1}", i + 1, Zufallszahl.ErzeugeZahlZwischen(1, 100));   
            }
        }
    }


    class Person
    {
        static public string Wohnort;

        public string Name;
        public int Alter;
        private int GeldAufDemKonto;

        public int Geburtsjahr()
        {
            return 2009 - Alter;
        }

        public static double multipli(double a, double b)
        {
            return a * b;
        }

        public static int berechneGeburtsjahr(int alter)
        {
            return 2009 - alter;
        }
    }


    class Program22
    {
        static void Main22(string[] args)
        {
            Person.Wohnort = "Berlin";

            Person mm_paule = new Person();
            mm_paule.Name = "Paule";
            mm_paule.Alter = 23;
            Console.WriteLine("{0} wurde {1} geboren", mm_paule.Name, mm_paule.Geburtsjahr());

            double mm_res = Person.multipli(23, 12.4);

            Person mm_emma = new Person();
            mm_emma.Name = "Emma";
            mm_emma.Alter = 21;

            WeitereKlasse mm_wwww = new WeitereKlasse();
            mm_wwww.dummy = 77;


        }
    }
}
