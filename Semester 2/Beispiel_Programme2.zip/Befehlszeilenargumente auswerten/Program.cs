using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Befehlszeilenargumente_auswerten
{
   static class Program
   {
      [STAThread]
      static void Main(string[] arguments)
      {
         // Auswerten der Befehlszeilenargumente
         bool debugMode = false;
         string imageFolder = null;
         string unknownArguments = null;
          //arguments ist ein Feld von Strings, das hier mit foreach durchlaufen wird
         foreach (string argument in arguments)
         {
            string argument4Check = argument.ToLower();
            if (argument4Check == "/debugmode")
            {
               debugMode = true;
            }
            else if (argument4Check.StartsWith("/imagefolder:"))
            {
               // Den Argumentwert auslesen
               imageFolder = argument.Substring(13, argument.Length - 13);
            }
            else
            {
               // Unbekanntes Argument
               if (unknownArguments != null)
               {
                  unknownArguments += ", ";
               }
               unknownArguments += argument;
            }
         }

         // Unbekannte Argumente auswerten
         if (unknownArguments != null)
         {
            MessageBox.Show("Die folgenden Argumente sind ung�ltig: " + unknownArguments,
               Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
         }
         else
         {
            // Anwendung mit den Argumenten starten
            Application.EnableVisualStyles();
            Application.Run(new StartForm(debugMode, imageFolder));
         }
      }
   }
}