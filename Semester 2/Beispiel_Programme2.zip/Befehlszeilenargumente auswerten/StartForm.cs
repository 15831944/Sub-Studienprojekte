using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Befehlszeilenargumente_auswerten
{
   public partial class StartForm : Form
   {
      public StartForm(bool debugMode, string imageFolder)
      {
         InitializeComponent();

         // Argumente auswerten
         this.infoLabel.Text = "debugMode: " + debugMode + Environment.NewLine +
            "imageFolder: " + imageFolder;
      }
   }
}