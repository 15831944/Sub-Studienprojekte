using System;
using System.Collections.Generic;
using System.Text;

namespace Klassentest
{
    class Person
    {
        public string Vorname;
        public string Nachname;
        public DateTime Geburtstag;
        public string PLZ;
        public string Ort;
        public string Strasse;

        public int AlterInTagen()
        {
            TimeSpan mm_diff = DateTime.Today - Geburtstag;
            return mm_diff.Days;  
        }
        public string Name()
        {
            return Vorname + " " + Nachname;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Person Paule = new Person();
            Paule.Vorname = "Paule";
            Paule.Nachname = "Schmidt";
            Paule.Geburtstag = DateTime.Parse("19.11.1987");
            Console.WriteLine(Paule.Name() + " ist " + Paule.AlterInTagen() + " Tage alt!");
            DateTime mm_alter = Paule.Geburtstag + TimeSpan.FromDays(20000);
            Console.WriteLine(Paule.Name() + " wird am " + mm_alter.ToShortDateString() + " 20000 Tage alt!");

        }
    }
}
