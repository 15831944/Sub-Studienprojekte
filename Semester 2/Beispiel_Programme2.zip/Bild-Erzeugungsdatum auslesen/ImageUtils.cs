﻿using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace Addison_Wesley.Codebook.Images
{
   public class ImageUtils
   {
      /// <summary>
      /// Liefert das Erstell- bzw. Aufnahmedatum des übergebenen Bilds
      /// </summary>
      /// <param name="bitmap">Das Bild</param>
      public static DateTime GetCreationDate(Bitmap bitmap)
      {
         const int PropertyTagDateTime = 0x0132;

         string result = null;
         for (int i = 0; i < bitmap.PropertyItems.Length; i++)
         {
            PropertyItem item = bitmap.PropertyItems[i];
            if (item.Id == PropertyTagDateTime)
            {
               // Den String ermitteln, der das Datum speichert
               for (int j = 0; j < item.Len - 1; j++)
               {
                  result += (char)item.Value[j];
               }

               // Versuch, den im Format yyyy:MM:dd hh:mm:ss 
               // ermittelten String in ein Datum zu konvertieren
               if (result != "0000:00:00 00:00:00")
               {
                  try
                  {
                     int year = Convert.ToInt32(result.Substring(0, 4));
                     int month = Convert.ToInt32(result.Substring(5, 2));
                     int day = Convert.ToInt32(result.Substring(8, 2));
                     int hour = Convert.ToInt32(result.Substring(11, 2));
                     int minute = Convert.ToInt32(result.Substring(14, 2));
                     int second = Convert.ToInt32(result.Substring(17, 2));

                     // Bitmap freigeben
                     bitmap.Dispose();

                     // Das Ergebnis zurückgeben
                     return new DateTime(year, month, day, hour, minute, second);
                  }
                  catch
                  {
                     throw new Exception("Der String '" + result +
                        "' kann nicht in einen DateTime-Wert " +
                        "konvertiert werden");
                  }
               }

               break;
            }
         }

         // Das Datum existiert nicht
         return new DateTime(0);
      }
   }
}
