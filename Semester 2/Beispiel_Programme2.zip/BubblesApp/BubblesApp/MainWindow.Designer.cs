﻿namespace bubbles
{
    partial class MainWindow
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWindow));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.punkte = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.anzfarben = new System.Windows.Forms.NumericUpDown();
            this.start = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.breite = new System.Windows.Forms.NumericUpDown();
            this.hoehe = new System.Windows.Forms.NumericUpDown();
            this.bilder = new System.Windows.Forms.ImageList(this.components);
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.anzeigePunkte = new System.Windows.Forms.ToolTip(this.components);
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.anzfarben)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.breite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hoehe)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.PaintEreignis);
            this.splitContainer1.Panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MouseOverPanel);
            this.splitContainer1.Panel1.Click += new System.EventHandler(this.PanelClick);
            this.splitContainer1.Panel1.Resize += new System.EventHandler(this.repaintAtResize);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.punkte);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.anzfarben);
            this.splitContainer1.Panel2.Controls.Add(this.start);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.breite);
            this.splitContainer1.Panel2.Controls.Add(this.hoehe);
            this.splitContainer1.Panel2.Padding = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Size = new System.Drawing.Size(447, 632);
            this.splitContainer1.SplitterDistance = 570;
            this.splitContainer1.TabIndex = 5;
            // 
            // punkte
            // 
            this.punkte.AutoSize = true;
            this.punkte.Location = new System.Drawing.Point(206, 25);
            this.punkte.Name = "punkte";
            this.punkte.Size = new System.Drawing.Size(0, 17);
            this.punkte.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(126, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Anzahl Farben";
            // 
            // anzfarben
            // 
            this.anzfarben.Location = new System.Drawing.Point(129, 24);
            this.anzfarben.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.anzfarben.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.anzfarben.Name = "anzfarben";
            this.anzfarben.Size = new System.Drawing.Size(39, 22);
            this.anzfarben.TabIndex = 10;
            this.anzfarben.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(332, 9);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(83, 32);
            this.start.TabIndex = 9;
            this.start.Text = "Start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Höhe";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Breite";
            // 
            // breite
            // 
            this.breite.Location = new System.Drawing.Point(7, 24);
            this.breite.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.breite.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.breite.Name = "breite";
            this.breite.Size = new System.Drawing.Size(45, 22);
            this.breite.TabIndex = 6;
            this.breite.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // hoehe
            // 
            this.hoehe.Location = new System.Drawing.Point(71, 24);
            this.hoehe.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.hoehe.Minimum = new decimal(new int[] {
            7,
            0,
            0,
            0});
            this.hoehe.Name = "hoehe";
            this.hoehe.Size = new System.Drawing.Size(39, 22);
            this.hoehe.TabIndex = 5;
            this.hoehe.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // bilder
            // 
            this.bilder.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("bilder.ImageStream")));
            this.bilder.TransparentColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bilder.Images.SetKeyName(0, "0.bmp");
            this.bilder.Images.SetKeyName(1, "1.bmp");
            this.bilder.Images.SetKeyName(2, "2.bmp");
            this.bilder.Images.SetKeyName(3, "3.bmp");
            this.bilder.Images.SetKeyName(4, "4.bmp");
            this.bilder.Images.SetKeyName(5, "5.bmp");
            this.bilder.Images.SetKeyName(6, "6.bmp");
            this.bilder.Images.SetKeyName(7, "7.bmp");
            this.bilder.Images.SetKeyName(8, "8.bmp");
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(116, 22);
            this.toolStripLabel1.Text = "toolStripLabel1";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 632);
            this.Controls.Add(this.splitContainer1);
            this.Name = "MainWindow";
            this.Text = "Bubbles";
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.anzfarben)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.breite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hoehe)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown breite;
        private System.Windows.Forms.NumericUpDown hoehe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown anzfarben;
        private System.Windows.Forms.ImageList bilder;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolTip anzeigePunkte;
        private System.Windows.Forms.Label punkte;
    }
}

