using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace bubbles
{
    /*partial hei�t Aufteilung der Klasse in mehrere cs-Dateien*/
    public partial class MainWindow : Form
    {
        #region private Member-Variablen
        //Das Spielfeld mit allen Feldern als rechteckiges Array
        private Spielfeld m_sf;
        private Graphics m_g;
        /*
         * Die Grafik, in die hinein gezeichnet wird
         */
        private Graphics myGraphics
        {
            get
            {
                if (null == m_g)
                {
                    m_g = Graphics.FromHwnd(splitContainer1.Panel1.Handle);
                }
                return m_g;
            }
        }
        #endregion

        /// <summary>
        /// wird gerufen, wenn Panel neue Gr��e bekommt
        /// dabei mu� Graphik neu gesetzt werden
        /// </summary>
        /// <param name="sender">Event-Verursacher</param>
        /// <param name="e">Event-Parameter</param>
        private void repaintAtResize(object sender, EventArgs e)
        {
            if (m_sf != null)
            {
                //Graphics-Objekt neu holen
                m_g = null;
                m_sf.pixelInX = splitContainer1.Panel1.Width;
                m_sf.pixelInY = splitContainer1.Panel1.Height;
                splitContainer1.Refresh();
            }
        }

        /// <summary>
        /// Bei F�llen des Panels Spielfeld erstellen und zeichnen
        /// </summary>
        /// <param name="sender">Event-Verursacher</param>
        /// <param name="e">Event-Parameter</param>
        private void start_Click(object sender, EventArgs e)
        {
            m_sf = new Spielfeld((int)breite.Value, (int)hoehe.Value, (int)anzfarben.Value);
            repaintAtResize(sender, e);
        }

        /// <summary>
        /// wird beim neuzeichnen des Objektes gerufen
        /// </summary>
        /// <param name="sender">Event-Verursacher</param>
        /// <param name="e">Paint-Event-Parameter</param>
        private void PaintEreignis(object sender, PaintEventArgs e)
        {
            if (m_sf != null)
            {
                punkte.Text = "" + m_sf.Punkte + " Punkte";
                //Nur dr�ber zeichnen, nicht neu generieren...
                m_sf.drawCurrent(myGraphics);
            }
        }

        /// <summary>
        /// Bei Maus auf Spielfeld werden zusammenh�ngende Felder markiert
        /// </summary>
        /// <param name="sender">Event-Verursacher</param>
        /// <param name="e">Event-Parameter</param>
        private void MouseOverPanel(object sender, MouseEventArgs e)
        {
            Point p = PointOfMouse();
            if (m_sf != null)
            {
                //Alle in Frage kommenden markieren
                int pkt;
                if (m_sf.markAllConnected(p, out pkt))
                {
                    //Nur dr�ber zeichnen, nicht neu generieren...
                    m_sf.drawCurrent(myGraphics);
                }
                //.. und Tooltip zeigen bzw. verstecken
                if (pkt >0)
                {
                    anzeigePunkte.Show("" + pkt + " Punkte", splitContainer1.Panel1, p.X + 10, p.Y);
                }
                else
                {
                    anzeigePunkte.Hide(splitContainer1.Panel1);  
                }
            }
        }

        /// <summary>
        /// Berechne Mausposition in Panelkoordinaten
        /// </summary>
        /// <returns>Die aktuelle Mausposition</returns>
        private Point PointOfMouse()
        {
            int mm_x, mm_y;
            mm_x = PointToClient(MousePosition).X;
            mm_y = PointToClient(MousePosition).Y;
            return new Point(mm_x, mm_y);
        }

        /// <summary>
        /// wird beim Klick aufs Panel (Spielfeld) gerufen - Click-Event
        /// </summary>
        /// <param name="sender">Event-Verursacher</param>
        /// <param name="e">Event-Parameter</param>
        private void PanelClick(object sender, EventArgs e)
        {
            if (true == m_sf.RemoveBubbleAt(PointOfMouse()))
            {
                //wenn etwas entfernt wurde, regenerieren
                splitContainer1.Panel1.Refresh();
            }
        }
    }
}
