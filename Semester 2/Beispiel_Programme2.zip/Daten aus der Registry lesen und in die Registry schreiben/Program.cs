using System;
using Samples;

namespace Registry_lesen_und_schreiben
{
   class Program
   {
      [STAThread]
      static void Main(string[] args)
      {
         Console.Title = "Daten aus der Registry lesen und in die Registry schreiben";

         // Wert des Eintrags HKEY_CURRENT_USER\Software\Microsoft\Office\
         // 11.0\Word\Options\DOC-PATH lesen
         object wordDocPath = RegUtils.ReadValue(RegistryRootKeys.HKEY_CURRENT_USER,
            @"Software\Microsoft\Office\11.0\Word\Options", "DOC-PATH", null);
         if (wordDocPath != null)
         {
            Console.WriteLine(wordDocPath);
         }
         else
         {
            Console.WriteLine("Eintrag nicht gefunden");
         }

         // Eintrag 
         // HKEY_CURRENT_USER\Software\Addison-Wesley\Codebook\Version 
         // so schreiben, dass der Eintrag inklusive allen Schl�sseln 
         // automatisch angelegt wird, falls er noch nicht existiert
         RegUtils.WriteValue(RegistryRootKeys.HKEY_CURRENT_USER,
            @"Software\kleinweich\Samples", "Version", "1.0", true);

         // Eintrag 
         // HKEY_CURRENT_USER\Software\Addison-Wesley\Codebook\Samples schreiben
         RegUtils.WriteValue(RegistryRootKeys.HKEY_CURRENT_USER,
            @"Software\kleinweich\Samples", "Registry",
            "c:\\Samples\\Registry", true);

         // Schl�ssel 
         // HKEY_CURRENT_USER\Software\Addison-Wesley\Codebook\Samples l�schen
         RegUtils.DeleteKey(RegistryRootKeys.HKEY_CURRENT_USER,
            @"Software\kleinweich\Samples");

         // DWord-Wert schreiben
         RegUtils.WriteValue(RegistryRootKeys.HKEY_CURRENT_USER,
            @"Software\kleinweich\Samples", "DWord-Test-Value", 123, true);

         // Binary-Wert schreiben
         byte[] data = new byte[255];
         for (byte i = 0; i < 255; i++)
         {
            data[i] = i;
         }
         RegUtils.WriteValue(RegistryRootKeys.HKEY_CURRENT_USER,
            @"Software\kleinweich\Samples", "Binary-Test-Value", data, true);

         Console.WriteLine();
         Console.WriteLine("Beenden mit Return");
         Console.ReadLine();
      }
   }
}
