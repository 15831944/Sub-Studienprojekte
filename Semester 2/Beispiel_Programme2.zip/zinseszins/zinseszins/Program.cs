using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Odbc;
using System.IO;

namespace zinseszins
{
    class Program
    {
        static void Main(string[] args)
        {

            int mm_zahl = inputInt("Zahl eingeben: ");
            int mm_ast = AnzahlStellen(mm_zahl);

            int mm_ste = getZahlAtStelle(mm_zahl, 2);
            int mm_ste4 = getZahlAtStelle(mm_zahl, 4);
            int mm_ste5 = getZahlAtStelle(mm_zahl, 5);


        }

        static int getZahlAtStelle(int zahl, int stelle)
        {
            int mm_ast = AnzahlStellen(zahl);
            if ((stelle >= 1) && (stelle <= mm_ast))
            {
                int mm_abz = (int)Math.Pow(10, mm_ast - stelle + 1);
                int mm_teil = (int)Math.Pow(10, mm_ast - stelle);
                int mm_rest = zahl % mm_abz;
                int mm_ret = mm_rest / mm_teil;
                return mm_ret;
            }
            return 0;

        }

        static int AnzahlStellen(int zahl)
        {
            double mm_log = Math.Log10(zahl);
            int az = 1 + (int) mm_log;
            return az;
        }


        static string gibText()
        {
            return "Hallo!";
        }

        static double inputDouble(string Eingabeaufforderung)
        {
            double mm_w;
            string mm_s;
            do
            {
                //Aufforderung
                Console.Write(Eingabeaufforderung);
                //Eingabe
                mm_s = Console.ReadLine();
                //Dezimaltrenner Punkt und Komma, Komma ist Standard
                //daher Punkt durch Komma ersetzen
                mm_s = mm_s.Replace(".", ",");
            }
            //Austrittsbedingung, Schleife nur verlassen, wenn Wert ok
            //dabei schreibt TryParse den double Wert in Variable mm_w
            while (false == double.TryParse(mm_s, out mm_w));
            return mm_w;
        }

        static int inputInt(string Eingabeaufforderung)
        {
            int mm_w;
            string mm_s;
            do
            {
                //Aufforderung
                Console.Write(Eingabeaufforderung);
                //Eingabe
                mm_s = Console.ReadLine();
            }
            //Austrittsbedingung, Schleife nur verlassen, wenn Wert ok
            //dabei schreibt TryParse den double Wert in Variable mm_w
            while (false == int.TryParse(mm_s, out mm_w));
            return mm_w;
        }
    }
}
