namespace Tastenbet�tigung_simulieren
{
   partial class StartForm
   {
      /// <summary>
      /// Erforderliche Designervariable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Verwendete Ressourcen bereinigen.
      /// </summary>
      /// <param name="disposing">True, wenn verwaltete Ressourcen gel�scht werden sollen; andernfalls False.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Vom Windows Form-Designer generierter Code

      /// <summary>
      /// Erforderliche Methode f�r die Designerunterst�tzung.
      /// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
      /// </summary>
      private void InitializeComponent()
      {
         this.demoButton = new System.Windows.Forms.Button();
         this.SuspendLayout();
         // 
         // demoButton
         // 
         this.demoButton.Location = new System.Drawing.Point(12, 12);
         this.demoButton.Name = "demoButton";
         this.demoButton.Size = new System.Drawing.Size(75, 23);
         this.demoButton.TabIndex = 0;
         this.demoButton.Text = "Demo";
         this.demoButton.UseVisualStyleBackColor = true;
         this.demoButton.Click += new System.EventHandler(this.demoButton_Click);
         // 
         // StartForm
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(377, 266);
         this.Controls.Add(this.demoButton);
         this.Name = "StartForm";
         this.Text = "Die Bet�tigung der Tastatur simulieren";
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.Button demoButton;
   }
}

