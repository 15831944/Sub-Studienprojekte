﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace turmVonHanoi
{
    /*
class Program
{
    static int umleg = 0;
    static void Main(string[] args)
    {
        //Eingabe...
        Console.Write("Bitte Anzahl der Scheiben angeben:");
        string mm_s = Console.ReadLine();
        int mm_anz = int.Parse(mm_s);

        //in die Rekursion
        variiere(mm_anz, 1, 2, 3);
        //Statistik ausgeben
        Console.Write("Fertig in {0} Schritten", umleg);
        Console.ReadLine();
    }

    //rekursive Methode
    static void variiere(int anz, int quelle, int temp, int ziel)
    {
        if (anz > 1)
        {
            variiere(anz - 1, quelle, ziel, temp);
        }
        Console.WriteLine("Bringe Scheibe {0} von Turm {1} nach Turm {2}",
            anz, quelle, temp);
        umleg++;
        if (anz > 1)
        {
            variiere(anz - 1, ziel, temp, quelle);
        }
    }
}
    */

    class Program
    {
        static int umleg = 0;
        static Turm[] hanoi;

        static void Main(string[] args)
        {
            int mm_anz=0;
            string mm_s;
            while ((mm_anz <= 0) || (mm_anz >12))
            {
                Console.Clear();  

                do
                {
                    Console.Write("Bitte Anzahl der Scheiben angeben:");
                    mm_s = Console.ReadLine();
                }
                while (int.TryParse(mm_s, out mm_anz) == false);
            }
            hanoi = new Turm[3];
            hanoi[0] = new Turm(mm_anz);
            hanoi[1] = new Turm(mm_anz);
            hanoi[2] = new Turm(mm_anz);

            for (int i = mm_anz; i >= 1; i--)
            {
                hanoi[0].addScheibe(i); 
            }
            //aktuelle Situation ausgeben....
            tuerme();
            //in die Rekursion
            variiere(mm_anz, 1, 2, 3);
            Console.Write("Fertig in {0} Schritten", umleg);
            Console.ReadLine();
        }

        static void tuerme()
        {
            hanoi[0].print(0);
            hanoi[1].print(1);
            hanoi[2].print(2);
        }
        static void schiebe(int von, int nach)
        {
            //Vor schieben warten
            Console.Write("Weiter mit Enter");
            Console.ReadLine();
            //schieben
            int mm_s;
            hanoi[von].removeScheibe(out mm_s);
            hanoi[nach].addScheibe(mm_s);
            //anzeigen
            tuerme();
        }

        static void variiere(int anz, int quelle, int temp, int ziel)
        {
            if (anz > 1)
            {
                variiere(anz - 1, quelle, ziel, temp);
            }
            schiebe(quelle - 1, temp - 1);
            //Console.WriteLine("Bringe Scheibe {0} von Turm {1} nach Turm {2}", anz, quelle, temp);
            umleg++;
            if (anz > 1)
            {
                variiere(anz - 1, ziel, temp, quelle);
            }
        }
    }
    
    class Turm
    {
        ArrayList m_stapel = new ArrayList();
        int m_maxanzahl;

        public Turm(int maxanzahl)
        {
            m_maxanzahl = maxanzahl;
        }

        public bool addScheibe(int size)
        {
            bool mm_ret = true;
            if ((m_stapel.Count == 0) || (((int) (m_stapel[m_stapel.Count - 1])) > size))
            {
                m_stapel.Add(size);
            }
            else
            {
                mm_ret = false;
            }
            return mm_ret;
        }

        public bool removeScheibe(out int scheibe)
        {
            bool mm_ret = true;
            if (m_stapel.Count == 0) 
            {
                scheibe  = 0;
                mm_ret = false;
            }
            else
            {
                scheibe = (int)m_stapel[m_stapel.Count - 1];
                m_stapel.RemoveAt(m_stapel.Count - 1);
            }
            return mm_ret;
        }


        public void print(int pos)
        {
            //von unten nach oben
            int mm_s;
            for (int i = 0; i<m_maxanzahl;i++)
            {
                if (m_stapel.Count > i)
                {
                    mm_s = (int) m_stapel[i];
                }
                else
                {
                    mm_s = 0;
                }
                Console.SetCursorPosition((2*pos)* m_maxanzahl+(pos*2), m_maxanzahl - i);
                for (int j = m_maxanzahl; j > 0; j--)
                {
                    if (mm_s >= j)
                    {
                        Console.Write("\u2588");
                    }
                    else
                    {
                        Console.Write(" "); 
                    }
                }
                Console.Write("|");
                for (int j = 0; j <= m_maxanzahl ; j++)
                {
                    if (mm_s >  j)
                    {
                        Console.Write("\u2588");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
            }
            Console.SetCursorPosition(0, m_maxanzahl + 1); 
        }
    }
}
