using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;


namespace tannenbaum
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            liste[0] = b1;
            liste[1] = b2;
            liste[2] = b3;
            liste[3] = b4;
            liste[0].Focus();
            mark(0);
        }

        private void speichernUnterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            sichernDialog.InitialDirectory = @"H:\Eigene_Dateien\Softwareentwicklung\bubbles";
            sichernDialog.ShowDialog();
            string file = sichernDialog.FileName;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                KontextMEnu.Show((Form)sender, e.Location);
            }
            else if (e.Button == MouseButtons.Left)
            {
                
                Graphics g = this.CreateGraphics();
                
                g.DrawImage(liste[aktuell].BackgroundImage, e.Location.X, e.Location.Y, liste[aktuell].Width, liste[aktuell].Height); 
                /*
                //Neue Picturebox erzeugen...
                PictureBox mm_pb = new System.Windows.Forms.PictureBox();
                //Eigenschaften aus gesetztem Button �bernehmen...
                mm_pb.BackgroundImage = liste[aktuell].BackgroundImage;
                mm_pb.Location = e.Location;
                mm_pb.Size = liste[aktuell].Size;
                mm_pb.BackColor = liste[aktuell].BackColor;
                mm_pb.BackgroundImageLayout = liste[aktuell].BackgroundImageLayout;
                mm_pb.BringToFront();
                //... in den Dialog aufnehmen
                this.Controls.Add(mm_pb);*/
            }
        }

        private void Einschalter_MouseHover(object sender, EventArgs e)
        {
            tooltip.Show("Einschalter dr�cken!!\naber schnell", (IWin32Window)sender);

        }

        private void mark(int welches)
        {
            for (int i = 0; i < anzahl; ++i)
            {
                if (welches == i)
                {
                    liste[i].FlatAppearance.BorderColor = Color.Black;
                    liste[i].FlatAppearance.BorderSize = 1;
                }
                else
                {
                    liste[i].FlatAppearance.BorderColor = Color.Black;
                    liste[i].FlatAppearance.BorderSize = 0;
                }
            }
        }

        private void b_Click(object sender, EventArgs e)
        {
            aktuell = (int)((Button) sender).Tag  ;
            mark(aktuell);
        }


        private const int anzahl = 4;
        private int aktuell = 0;
        Button[] liste = new Button[anzahl];


    }
}