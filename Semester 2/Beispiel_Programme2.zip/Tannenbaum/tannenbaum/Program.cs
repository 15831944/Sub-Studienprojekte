﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace tannenbaum
{
    static class Program
    {
        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Hier wird neues Objekt der Klasse Form1 erzeugt 
            //und in Endlos-Warteschleife gebracht
            Application.Run(new Form1());
        }
    }
}