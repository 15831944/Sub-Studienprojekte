using System;
using System.Collections.Generic;
using System.Text;

namespace kapselung
{
    class Punkt
    {
        private double m_r, m_W;
        public double X
        {
            get
            {
                return m_R*cos(m_W);
            }
            set
            {
                m_X = value;
            }
        }
        public double Y
        {
            get
            {
                return m_Y;
            }
            set
            {
                m_Y = value;
            }
        }
        public double R
        {
            get
            {
                return m_R;
            }
            set
            {
                m_R = value;
                m_X = m_R * Math.Cos(m_W);
                m_Y = m_R * Math.Sin(m_W);

            }
        }
        public double W
        {
            get
            {
                return m_W;
                m_X = m_R * Math.Cos(m_W);
                m_Y = m_R * Math.Sin(m_W);
            }
            set
            {
                m_W = value;
                m_X = m_R * Math.Cos(m_W);
                m_Y = m_R * Math.Sin(m_W);
            }
        }
    }



    class Program
    {
        static void Main(string[] args)
        {
            Punkt obj = new Punkt();
            obj.X = 13;
            Console.WriteLine(obj.X);
        }
    }
}
