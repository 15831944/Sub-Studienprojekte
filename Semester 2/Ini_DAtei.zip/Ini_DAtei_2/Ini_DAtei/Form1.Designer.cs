﻿namespace Ini_DAtei
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.dateipfad_textbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sektionen_ListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.attribute_Listbox = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Werte_Listbox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(690, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateipfad_textbox
            // 
            this.dateipfad_textbox.Location = new System.Drawing.Point(12, 34);
            this.dateipfad_textbox.Name = "dateipfad_textbox";
            this.dateipfad_textbox.Size = new System.Drawing.Size(390, 20);
            this.dateipfad_textbox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Dateipfad";
            // 
            // sektionen_ListBox
            // 
            this.sektionen_ListBox.FormattingEnabled = true;
            this.sektionen_ListBox.Location = new System.Drawing.Point(15, 112);
            this.sektionen_ListBox.Name = "sektionen_ListBox";
            this.sektionen_ListBox.ScrollAlwaysVisible = true;
            this.sektionen_ListBox.Size = new System.Drawing.Size(207, 342);
            this.sektionen_ListBox.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Sektionen";
            // 
            // attribute_Listbox
            // 
            this.attribute_Listbox.FormattingEnabled = true;
            this.attribute_Listbox.Location = new System.Drawing.Point(248, 112);
            this.attribute_Listbox.Name = "attribute_Listbox";
            this.attribute_Listbox.ScrollAlwaysVisible = true;
            this.attribute_Listbox.Size = new System.Drawing.Size(203, 342);
            this.attribute_Listbox.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Attributte";
            // 
            // Werte_Listbox
            // 
            this.Werte_Listbox.FormattingEnabled = true;
            this.Werte_Listbox.Location = new System.Drawing.Point(472, 112);
            this.Werte_Listbox.Name = "Werte_Listbox";
            this.Werte_Listbox.ScrollAlwaysVisible = true;
            this.Werte_Listbox.Size = new System.Drawing.Size(203, 342);
            this.Werte_Listbox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 481);
            this.Controls.Add(this.Werte_Listbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.attribute_Listbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sektionen_ListBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateipfad_textbox);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox dateipfad_textbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox sektionen_ListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox attribute_Listbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox Werte_Listbox;
    }
}

