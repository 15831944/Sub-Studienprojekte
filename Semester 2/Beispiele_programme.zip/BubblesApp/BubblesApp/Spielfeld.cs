using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Drawing.Drawing2D;

namespace bubbles
{
    /// <summary>
    /// Das Feld repr�sentiert eine Kugel, merkt sich aber nicht
    /// deren Position, stellt nur die Bitmap f�r das Zeichnen und
    /// die M�glichkeit zum Markieren bereit
    /// </summary>
    class Feld
    {
        #region Member-Variablen
        private eFarbe m_Farbe;
        public short Marked;
        #endregion

        #region statische Member-Variablen
        public static ImageList bilder;
        public static int MaximalAnzahlFarben;
        private static Random m_rand = new Random();
        private static Bitmap[] m_bitmaps = new Bitmap[9];
        private static int m_MarkCol = 8;
        #endregion

        /// <summary>
        /// Konstruktor, Zufallsfarbe f�r Feld wird generiert
        /// </summary>
        public Feld()
        {
            int mm_col = m_rand.Next(0, MaximalAnzahlFarben);
            m_Farbe = (eFarbe)mm_col;
        }

        /// <summary>
        /// Farbm�glichkeiten...
        /// </summary>
        public enum eFarbe
        {
            rot = 0,
            gelb = 1,
            gr�n = 2,
            blau = 3,
            magenta = 4,
            cyan = 5,
            dunkelgr�n = 6,
            hellgruen = 7,
            markiert = 8,
        }
        /// <summary>
        /// Property Farbe
        /// </summary>
        public eFarbe Farbe
        {
            get
            {
                return m_Farbe;
            }
        }
        /// <summary>
        /// Property MarkedBitmap (f�r markiertes Feld)
        /// </summary>
        public Bitmap MarkedBitmap
        {
            get
            {
                if (m_bitmaps[m_MarkCol] == null)
                {
                    m_bitmaps[m_MarkCol] = new Bitmap(bilder.Images[m_MarkCol]);
                }
                return m_bitmaps[m_MarkCol];
            }
        }

        /// <summary>
        /// Property Bitmap
        /// </summary>
        public Bitmap Bitmap
        {
            get
            {
                int mm_col = (int)m_Farbe;

                if (m_bitmaps[mm_col] == null)
                {
                    m_bitmaps[mm_col] = new Bitmap(bilder.Images[mm_col]);
                }
                return m_bitmaps[mm_col];
            }
        }
    }

    /*******************************************************************
     * 
     *                             SPIELFELD 
     * 
     ********************************************************************/

    class Spielfeld
    {
        #region Variablen
        //Punkte im Spiel gesammelt
        private int m_punkte;
        //Wieviel sind markiert??
        private int m_countMarked;
        //Abstand zwischen Bitmaps
        static public int Offset = 32;
        //Zuletzt gemerkter Punkt (x,y) f�r Markierung
        static private Point m_lastMarked;
        //Gr��e des Rechtecks
        private int m_x, m_y;
        //Rechteck-Array mit Feld-Objekten
        private Feld[,] m_feld;
        //Startposition f�rs Zeichnen im Panel
        private int m_startPositionX, m_startPositionY;
        //Gr��e des Spielfeldes (Panels)
        private int m_pixelInX, m_pixelInY;
        #endregion
        #region Punkte in Selektion und Gesamtspiel
        //Lesender Zugriff auf Punkte von au�en
        public int Punkte
        {
            get
            {
                return m_punkte;
            }
        }
        //... und innen f�r markierte Punkte
        public int PunkteFuerMarkierung
        {
            get
            {
                int mm_pkt = 0;
                for (int i = 1; i < m_countMarked; i++)
                {
                    mm_pkt += i * 2;
                }
                return mm_pkt;
            }
        }
        #endregion
        #region Zeichenbereichsgr��e
        public int pixelInX
        {
            get
            {
                return m_pixelInX;
            }
            set
            {
                m_pixelInX = value;
                //Wo wird losgezeichnet
                m_startPositionX = (int)(0.5 * (value - m_x * Offset));
            }
        }
        public int pixelInY
        {
            get
            {
                return m_pixelInY;
            }
            set
            {
                m_pixelInY = value;
                m_startPositionY = value - 15;
            }
        }
        #endregion


        /// <summary>
        /// Konstruktor mit Feldgr��e und maximaler Farbenanzahl
        /// </summary>
        /// <param name="size_x">Gr��e des Feldes in x-Richtung</param>
        /// <param name="size_y">Gr��e des Feldes in y-Richtung</param>
        /// <param name="max_color">MaximalAnzahl unterschiedlicher Farben</param>
        public Spielfeld(int size_x, int size_y, int max_color)
        {
            m_punkte = 0;
            m_x = size_x;
            m_y = size_y;
            m_feld = new Feld[m_x, m_y];
            //Spielfeld mit Feld-Objekten inititalisieren...
            Feld.MaximalAnzahlFarben = max_color;
            for (int i = 0; i < m_x; ++i)
            {
                for (int j = 0; j < m_y; ++j)
                {
                    m_feld[i, j] = new Feld();
                }
            }
        }

        /// <summary>
        /// Aus Windowsposition der Maus Position in Panel (Spielfeld)-Koordinaten
        /// </summary>
        /// <param name="windowpos">Windowsposition der Maus</param>
        /// <returns>Position im Spielfeld</returns>
        private Point MousePosToFeldIndex(Point windowpos)
        {
            int mm_xp = windowpos.X - m_startPositionX >= 0 ? (windowpos.X - m_startPositionX) / Offset : -1;
            int mm_yp = (m_startPositionY - windowpos.Y) / Offset;
            return new Point(mm_xp, mm_yp);
        }

        /// <summary>
        /// Markierung aller Elemente r�ckg�ngig machen
        /// </summary>
        private void unmarkAll()
        {
            for (int i = 0; i < m_x; ++i)
            {
                for (int j = 0; j < m_y; ++j)
                {
                    if (m_feld[i, j] != null)
                    {
                        m_feld[i, j].Marked = 0;
                    }
                }
            }
            m_countMarked = 0;
        }

        /// <summary>
        /// liegt x,y in aktuellem Feld??
        /// </summary>
        /// <param name="x">x-Position im Spielfeld</param>
        /// <param name="y">y-Position im Spielfeld</param>
        /// <returns>true, wenn x, y in Spielfeld, sonst false</returns>
        private bool isPosInArray(int x, int y)
        {
            bool mm_ret = false;
            if ((x < m_x) && (x >= 0))
            {
                if ((y < m_y) && (y >= 0))
                {
                    mm_ret = true;
                }
            }
            return mm_ret;
        }

        /// <summary>
        /// Hole Feld an Stelle x,y
        /// return ist true, wenn x,y im Feld liegt, sonst false
        /// sfeld kann auch null sein, wenn kein Feld-Objekt mehr vorhanden
        /// </summary>
        /// <param name="x">x-Position im Spielfeld</param>
        /// <param name="y">y-Position im Spielfeld</param>
        /// <param name="sfeld">R�ckgabe des Feldes, kann auch null sein</param>
        /// <returns>true, wenn x, y in Spielfeld, sonst false</returns>
        private bool getFeldAt(int x, int y, out Feld sfeld)
        {
            bool mm_ret = false;
            sfeld = null;
            if (isPosInArray(x, y))
            {
                sfeld = m_feld[x, y];
                mm_ret = true;
            }
            return mm_ret;
        }

        /// <summary>
        /// suche um Feld x, y nach Farbe col - Rekursive Funktion
        /// </summary>
        /// <param name="x">aktuelle x-Position</param>
        /// <param name="y">aktuelle y-Position</param>
        /// <param name="col">suche um x,y nach Felder mit Farbe col</param>
        private void searchNext(int x, int y, Feld.eFarbe col)
        {
            int mm_x, mm_y;
            for (int i = 0; i < 4; i++)
            {
                Feld mm_f;
                mm_x = x + (i % 2 != 0 ? i - 2 : 0);
                mm_y = y + (i % 2 == 0 ? i - 1 : 0);
                //Zu allen Seiten suchen
                if (getFeldAt(mm_x, mm_y, out mm_f))
                {
                    if (mm_f != null)
                    {
                        //Wenn Punkt gleiche Farbe hat
                        if (mm_f.Farbe == col)
                        {
                            //.. und noch nicht markiert wurde
                            if (mm_f.Marked == 0)
                            {
                                mm_f.Marked = 1;
                                m_countMarked++;
                                //..in die Rekursion
                                searchNext(mm_x, mm_y, col);
                            }
                        }
                        else
                        {
                            //Schon betrachtet, aber falsche Farbe
                            mm_f.Marked = -1;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Markiert alle Feld-Objekte, die den Regeln entsprechend
        /// an Position windowpos liegen, markiert die Elemente
        /// </summary>
        /// <param name="windowpos">Aktuelle Mausposition in Spielfeld</param>
        /// <param name="Punkte">R�ckgabe Punktezahl f�r zusammenh�ngende Elemente</param>
        /// <returns>true, wenn mehr als zwei Elemente zusammenh�ngen, sonst false</returns>
        public bool markAllConnected(Point windowpos, out int Punkte)
        {
            Feld mm_f;
            Point p = MousePosToFeldIndex(windowpos);
            bool mm_bb = true;
            if (m_lastMarked != null)
            {
                mm_bb = isPosInArray(m_lastMarked.X, m_lastMarked.Y) == false;
            }
            if ((p == m_lastMarked) || ((isPosInArray(p.X, p.Y) == false) && (mm_bb)))
            {
                Punkte = PunkteFuerMarkierung;
                return false;
            }
            m_countMarked = 0;
            m_lastMarked = p;
            unmarkAll();
            //Alle im Umfeld suchen, die gerade verbunden sind...
            if (getFeldAt(p.X, p.Y, out mm_f))
            {
                if (mm_f != null)
                {
                    mm_f.Marked = 1;
                    m_countMarked++;
                    //.. in die Rekursion...
                    searchNext(p.X, p.Y, mm_f.Farbe);
                }
            }
            //Anzahl markierter Elemente gibt Punktezahl...
            Punkte = PunkteFuerMarkierung;
            return (m_countMarked>1) ;
        }

        /// <summary>
        /// Entfernt zusammenh�ngende Felder an windowpos und l��t die Felder dar�ber herunterpurzeln
        /// Delegieren an �berladene RemoveBubbleAt-Methode
        /// </summary>
        /// <param name="windowpos">Stelle im Spielfeld in Pixel</param>
        /// <returns>true, wenn etwas entfernt wurde, sonst false</returns>
        public bool RemoveBubbleAt(Point windowpos)
        {
            Point p = MousePosToFeldIndex(windowpos);
            return RemoveBubbleAt(p.X, p.Y);
        }

        /// <summary>
        /// Entfernt leere Spalten nach dem Entfernen eines zusammenh�ngenden Feldes
        /// </summary>
        private void EntferneLeereSpalten()
        {
            //Wenn Spalte leer, dann von rechts heranr�cken...
            for (int i = 0; i < m_x; ++i)
            {
                if (m_feld[i, 0] == null)
                {
                    //Alle spalten ab aktueller verschieben...
                    for (int j = i; j < m_x - 1; j++)
                    {
                        for (int k = 0; k < m_y; k++)
                        {
                            m_feld[j, k] = m_feld[j + 1, k];
                            m_feld[j + 1, k] = null;
                        }
                    }
                    //Gleiche Spalte nochmal untersuchen
                    i--;
                    //Anzahl der Spalten ist geringer
                    m_x--;
                }
            }
        }

        /*
         * 
         */
        /// <summary>
        /// l�scht das Feld-Objekt an xpos, ypos und l��t
        /// die Feldobjekte dar�ber nach unten fallen
        /// </summary>
        /// <param name="x">x-Koordinate des zu l�schenden Feldes</param>
        /// <param name="y">y-Koordinate des zu l�schenden Feldes</param>
        /// <returns>true, wenn es erfolgreich war, sonst false</returns>
        private bool removeBubbleInternal(int x, int y)
        {
            bool mm_ret = false;
            if (isPosInArray(x, y))
            {
                for (int j = y; j < m_y - 1; ++j)
                {
                    m_feld[x, j] = m_feld[x, j + 1];
                }
                m_feld[x, m_y - 1] = null;
                mm_ret = true;
            }
            return mm_ret;
        }

        /// <summary>
        /// Sucht das Feld von oben nach unten nach markierten
        /// Elementen durch und entfernt dann mit removeBubbleInternal
        /// </summary>
        /// <param name="x">x-FeldKoordinate des Startfeldes</param>
        /// <param name="y">y-FeldKoordinate des Startfeldes</param>
        /// <returns>true, wenn erfolgreich, sonst false</returns>
        public bool RemoveBubbleAt(int x, int y)
        {
            bool mm_ret = false;
            Feld mm_cur;
            if (m_countMarked <= 1) return false;
            m_punkte += PunkteFuerMarkierung;

            if (getFeldAt(x, y, out mm_cur))
            {
                if (mm_cur != null)
                {
                    if (mm_cur.Marked == 1)
                    {
                        //Von oben nach unten alle markierten entfernen...
                        for (int j = m_y - 1; j >= 0; j--)
                        {
                            for (int i = 0; i < m_x; i++)
                            {
                                Feld mm_rem;
                                if (getFeldAt(i, j, out mm_rem))
                                {
                                    if (null != mm_rem)
                                    {
                                        if (mm_rem.Marked == 1)
                                        {
                                            removeBubbleInternal(i, j);
                                        }
                                    }
                                }
                            }
                        }
                        mm_ret = true;
                    }
                }
            }
            unmarkAll();
            //Spalten l�schen
            EntferneLeereSpalten();
            return mm_ret;
        }

        /// <summary>
        /// Zeichne aktuelle Spiel-Situation des Spielfeldes
        /// </summary>
        /// <param name="g">Graphics-Objekt, in das gezeichnet wird</param>
        public void drawCurrent(Graphics g)
        {
            //Unten links suchen
            pixelInX = m_pixelInX; 

            for (int i = 0; i < m_x; ++i)
            {
                for (int j = 0; j < m_y; ++j)
                {
                    if (m_feld[i, j] != null)
                    {
                        if ((m_countMarked > 1) && (m_feld[i, j].Marked == 1))
                        {
                            //Wenn markiert wird, entsprechende Bitmap des Feldes holen
                            g.DrawImageUnscaled(m_feld[i, j].MarkedBitmap, m_startPositionX + i * Offset, m_startPositionY - (j + 1) * Offset);
                        }
                        else
                        {
                            //normale Bitmap holen
                            g.DrawImageUnscaled(m_feld[i, j].Bitmap, m_startPositionX + i * Offset, m_startPositionY - (j + 1) * Offset);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Indexer auf das Feld, um auf konkretes Feld von au�en zugreifen zu k�nnen
        /// hier nicht unbedingt erforderlich
        /// </summary>
        /// <param name="x">x-FeldKoordinate des Startfeldes</param>
        /// <param name="y">y-FeldKoordinate des Startfeldes</param>
        /// <returns></returns>
        public Feld this[int x, int y]
        {
            get
            {
                if (isPosInArray(x, y))
                {
                    return m_feld[x, y];
                }
                return null;
            }
        }
    }
}
