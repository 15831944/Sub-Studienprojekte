using System;
using System;
using System.Data.OleDb;
using System.Collections.Generic;
using System.Text;

namespace person
{
    class datenbank
    {

        public static void Main()
        {
            Inventor.Application m_InventorApplication;
            try
            {
                try
                {
                    // Get active inventor object
                    m_InventorApplication = System.Runtime.InteropServices.Marshal.GetActiveObject("Inventor.Application") as Inventor.Application;
                }
                catch (COMException)
                {
                    MessageBox.Show("AutoBolts : Inventor must be running.");
                    return false;
                }
                // Make sure that at least one document is opened
                m_AssemblyDocument = m_InventorApplication.ActiveDocument as AssemblyDocument;
                if (m_AssemblyDocument == null)
                {
                    MessageBox.Show("AutoBolts : An assembly document must be active.");
                    return false;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return false;
            }

            return true;
        }



        public static void Main22()
        {
            //create the database connection
            OleDbConnection aConnection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=H:\\Eigene_Dateien\\db1.mdb");

            //create the command object and store the sql query
            OleDbCommand aCommand = new OleDbCommand("select * from doedel", aConnection);
            try
            {
                aConnection.Open();

                //create the datareader object to connect to table
                OleDbDataReader aReader = aCommand.ExecuteReader();
                Console.WriteLine("This is the returned data from emp_test table");

                //Iterate throuth the database
                while (aReader.Read())
                {
                    Console.WriteLine("{0} - {1}", aReader.GetInt32(0).ToString(), aReader[4].ToString());
                }

                //close the reader 
                aReader.Close();

                //close the connection Its important.
                aConnection.Close();
            }

            //Some usual exception handling
            catch (OleDbException e)
            {
                Console.WriteLine("Error: {0}", e.Errors[0].Message);
            }
        }
    }
}
