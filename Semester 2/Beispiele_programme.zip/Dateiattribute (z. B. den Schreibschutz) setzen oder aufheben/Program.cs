using System;
using System.IO;
using System.Reflection;
using Addison_Wesley.Codebook.Utils;
using System.Diagnostics;

namespace Dateiattribute_setzen
{
   class Program
   {
      [STAThread]
      static void Main(string[] args)
      {
         Console.Title = "Dateiattribute (z. B. den Schreibschutz) setzen oder aufheben";

         string applicationPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
         string filename = Path.Combine(applicationPath, "Hitchhiker.txt");

         // Die Datei verstecken und schreibsch�tzen
         FileUtils.SetFileAttributes(filename, FileAttributes.Hidden | FileAttributes.ReadOnly);

         // Explorer im Anwendungsordner �ffnen
         Process.Start("Explorer", applicationPath);

         Console.WriteLine("Die Datei '" + filename + "' ist nun versteckt und schreibgesch�tzt");
         Console.WriteLine("Weiter mit Return");
         Console.ReadLine();

         // Das Hidden- und das Schreibschutzattribut wieder aufheben
         FileUtils.RemoveFileAttributes(filename, FileAttributes.Hidden | FileAttributes.ReadOnly);

         Console.WriteLine("Die Datei '" + filename + "' ist nun wieder nicht versteckt und nicht schreibgesch�tzt");

         Console.WriteLine();
         Console.WriteLine("Beenden mit Return");
         Console.ReadLine();
      }
   }
}
