﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace meinErstesCAD
{
    public class clsLineRectangle
    {
        Rectangle SelectRect = new Rectangle();
        Point ps = new Point();
        Point pe = new Point();

        public void clsLineRectangle_OnMouseDown(Object sender, MouseEventArgs e)
        {
            SelectRect.Width = 0;
            SelectRect.Height = 0;
            SelectRect.X = e.X;
            SelectRect.Y = e.Y;

            ps.X = e.X;
            ps.Y = e.Y;
            pe = ps;
        }

        public void clsLineRectangle_OnMouseMove(Object sender, MouseEventArgs e)
        {
            Form1 thisform = (Form1)sender;
            if (e.Button == MouseButtons.Left)
            {
                // First DrawReversible to toggle to the background color
                // Second DrawReversible to toggle to the specified color
                if (thisform.rdoLine.Checked)
                {

                    ControlPaint.DrawReversibleLine(thisform.PointToScreen(ps), thisform.PointToScreen(pe), Color.Black);
                    pe = new Point(e.X, e.Y);
                    ControlPaint.DrawReversibleLine(thisform.PointToScreen(ps), thisform.PointToScreen(pe), Color.Black);
                }
                else
                {
                    ControlPaint.DrawReversibleFrame(thisform.RectangleToScreen(SelectRect), Color.Black, FrameStyle.Dashed);
                    SelectRect.Width = e.X - SelectRect.X;
                    SelectRect.Height = e.Y - SelectRect.Y;
                    ControlPaint.DrawReversibleFrame(thisform.RectangleToScreen(SelectRect), Color.Black, FrameStyle.Dashed);
                }
            }
        }

        public void clsLineRectangle_OnMouseUp(Object sender, MouseEventArgs e)
        {
            Form1 thisform = (Form1)sender;
            Graphics g = thisform.CreateGraphics();
            //g.Restore(transState); 
            Pen p = new Pen(Color.Blue, 2);
            if (thisform.rdoLine.Checked)
            {
                //Neue Linie erstellen...
                thisform.m_elementListe.Add(new Linie(ps.X, ps.Y, pe.X, pe.Y));
                
                ControlPaint.DrawReversibleLine(thisform.PointToScreen(ps), thisform.PointToScreen(pe), Color.Black);
                g.DrawLine(p, ps, pe);
            }
            else
            {
                Rechteck m_re = new Rechteck();
                m_re.Untenlinks.X = SelectRect.X;
                m_re.Untenlinks.Y = SelectRect.Y;
                m_re.Offset.X = SelectRect.Width;
                m_re.Offset.Y = SelectRect.Height;
                thisform.m_elementListe.Add(m_re);

                ControlPaint.DrawReversibleFrame(thisform.RectangleToScreen(SelectRect), Color.Black, FrameStyle.Dashed);
                g.DrawRectangle(p, SelectRect);
                //g.Restore 
            }
            g.Dispose();
        }
    }
}
