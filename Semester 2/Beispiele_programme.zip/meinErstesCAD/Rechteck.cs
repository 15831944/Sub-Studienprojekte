﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace meinErstesCAD
{
    class Rechteck : Kurve
    {
        public Punkt Untenlinks;
        public Punkt Offset;

        public Rechteck()
        {
            Untenlinks = new Punkt();
            Offset = new Punkt();
        }

        public override void ZeichneDich(Graphics g)
        {
            Point sp = new Point((int)Untenlinks.X, (int)Untenlinks.Y);
            Point ep = new Point((int)Offset.X, (int)Offset.Y);
            g.DrawRectangle (m_pen, sp.X , sp.Y, ep.X, ep.Y);
        }
    }
}
