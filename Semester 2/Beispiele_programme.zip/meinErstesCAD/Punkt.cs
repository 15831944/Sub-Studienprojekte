﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace meinErstesCAD
{
    public class Punkt
    {
        public double X;
        public double Y;
    }
}
