﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace meinErstesCAD
{
    public class Kurve
    {
        protected Pen m_pen;

        public Kurve()
        {
            m_pen = new Pen(Color.Blue, 2);
        }

        public virtual void ZeichneDich(Graphics g)
        {
        }
    }
}
