﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace meinErstesCAD
{

    public partial class Form1 : Form
    {
        public List<Kurve> m_elementListe;

        public Form1()
        {
            InitializeComponent();
            clsLineRectangle im = new clsLineRectangle();
            this.MouseDown += new MouseEventHandler(im.clsLineRectangle_OnMouseDown);
            this.MouseMove += new MouseEventHandler(im.clsLineRectangle_OnMouseMove);
            this.MouseUp += new MouseEventHandler(im.clsLineRectangle_OnMouseUp);

            m_elementListe = new List<Kurve>();


            /*
            
            Linie m_neu = new Linie();
            m_neu.Endpunkt.X = 1;
            m_neu.Endpunkt.Y = 2;
            m_neu.Startpunkt.X = 7;
            m_neu.Startpunkt.Y = 9;
            m_linienliste.Add(m_neu);
            m_neu = new Linie(10, 20, 3, 4);
            m_linienliste.Add(m_neu); */

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //MessageBox.Show("PAINT!");

            foreach (Kurve element in m_elementListe)
            {
                element.ZeichneDich(e.Graphics);
            }
        }

        private void rdoRect_Click(object sender, EventArgs e)
        {

        }


    }
}

