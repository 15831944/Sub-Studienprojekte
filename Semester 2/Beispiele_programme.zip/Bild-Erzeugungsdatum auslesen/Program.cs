using System;
using Addison_Wesley.Codebook.Images;
using System.IO;
using System.Drawing;
using System.Reflection;

namespace Bild_Erzeugungsdatum
{
   class Program
   {
      [STAThread]
      static void Main(string[] args)
      {
         Console.Title = "Das Erzeugungsdatum eines Bilds auslesen";

         // Alle JPEG-Bilder aus dem Programmverzeichnis einlesen
         string applicationPath = Path.GetDirectoryName(
            Assembly.GetEntryAssembly().Location);
         DirectoryInfo di = new DirectoryInfo(applicationPath);
         foreach (FileInfo file in di.GetFiles("*.jpg"))
         {
            // Bitmap f�r das Bild erzeugen
            string filename = file.FullName;
            using (Bitmap bitmap = new Bitmap(filename))
            {
               // Erzeugungsdatum auslesen
               DateTime creationDate = ImageUtils.GetCreationDate(bitmap);
               Console.WriteLine("{0} wurde am {1} aufgenommen", file.Name, creationDate);
            }
         }

         Console.WriteLine();
         Console.WriteLine("Beenden mit Return");
         Console.ReadLine();
      }
   }
}
