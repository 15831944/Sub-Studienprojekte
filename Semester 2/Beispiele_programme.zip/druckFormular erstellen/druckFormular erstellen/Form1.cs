﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]

        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest,
            int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;
       
        private void CaptureScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width,
                this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void printDocument1_PrintPage(System.Object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        private void PrintDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Graphics gr = e.Graphics;
            Font fnt = new Font("Arial", 12, FontStyle.Regular);
            Brush br = Brushes.Black;

            string t1 = "Willi";                         // Begünstigter 
            gr.DrawString(t1, fnt, br, 23, 51);           // Maße in Pixel 

            string t2 = "1234566";                         // Konto-Nr. des Begünstigten 
            gr.DrawString(t2, fnt, br, 23, 85);

            string t3 = "99887766";                         // Bankleitzahl 
            gr.DrawString(t3, fnt, br, 399, 85);

            string t4 = "BankBank";                         // Kreditinstitut des Begünstigten 
            gr.DrawString(t4, fnt, br, 23, 119);

            //string t5 = TB5.Text;                       // Währung 
            //gr.DrawString(t5, fnt, br, 323, 151);

            string t6 = "1,23";                         // Betrag 
            gr.DrawString(t6, fnt, br, 323, 152);

            string t7 = "keiner";                         // Verwendungszweck1 
            gr.DrawString(t7, fnt, br, 23, 184);

            string t8 = "immer noch keiner";                         // Verwendungszweck2 
            gr.DrawString(t8, fnt, br, 23, 217);

            string t9 = "Paul";                         // Kontoinhaber  
            gr.DrawString(t9, fnt, br, 23, 249);

            string t10 = "223344";                       // Konto des Kontoinhabers 
            gr.DrawString(t10, fnt, br, 23, 284);

            string t11 = "13.06.2010";                      // Datum 
            gr.DrawString(t11, fnt, br, 235, 320);

            fnt.Dispose();
        }

        private void bt1_Click(object sender, EventArgs e)
        {
            CaptureScreen();
            printPreviewDialog1.Document = this.printDocument1;

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                this.printDocument1.Print();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = this.printDocument2;

            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                this.printDocument2.Print();
            }

        }
    }
}
