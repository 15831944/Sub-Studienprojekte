﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PersonGui
{
  class Person
  {
    public string Name;
    public string Vorname;
    public DateTime GeburtsDatum;
    public static string RandZeichen;
    public static int RandAbstand;
    private int ZeilenLaenge;

    public void showMessagebox()
    {
      MessageBox.Show(this.Vorname + " " + this.Name + "\nGeburtstag: " + 
        this.GeburtsDatum.ToShortDateString(), "Infos zur Person", 
        MessageBoxButtons.OK, MessageBoxIcon.Information);
    }


    public void sagHallo()
    {
      this.ZeilenLaenge = 6 + 2 + this.Name.Length + 2 * Person.RandAbstand;
      this.Zeile1();
      this.ZwischenZeilen();
      this.MittlereZeile();
      this.ZwischenZeilen();
      this.Zeile1();
    }

    public static Person erzeugeNeuePerson()
    {
      Person mm_ret = new Person();

      Console.Write("Namen: ");
      mm_ret.Name = Console.ReadLine();

      Console.Write("Geburtsdatum: ");
      mm_ret.GeburtsDatum = DateTime.Parse(Console.ReadLine());

      return mm_ret;
    }

    public int GibMirDeinAlterInTagen()
    {
      TimeSpan spanne = DateTime.Today - this.GeburtsDatum;
      return spanne.Days;
    }

    #region private Funktionen

    private void Zeile1()
    {
      for (int i = 0; i < this.ZeilenLaenge; i = i + 1)
      {
        Console.Write(Person.RandZeichen);
      }
      Console.WriteLine();
    }

    private void ZwischenZeilen()
    {
      for (int i = 0; i < Person.RandAbstand; i = i + 1)
      {
        Console.Write(Person.RandZeichen);
        for (int j = 0; j < this.ZeilenLaenge - 2; j = j + 1)
        {
          Console.Write(" ");
        }
        Console.WriteLine(Person.RandZeichen);
      }
    }

    private void MittlereZeile()
    {
      Console.Write(Person.RandZeichen);
      for (int i = 0; i < Person.RandAbstand; i = i + 1)
      {
        Console.Write(" ");
      }
      Console.Write("Hallo " + this.Name);
      for (int i = 0; i < Person.RandAbstand; i = i + 1)
      {
        Console.Write(" ");
      }
      Console.WriteLine(Person.RandZeichen);
    }

    #endregion

    public int GibMirDeinAlterInWochen()
    {
      int mon = DateTime.Today.Month;
      int gmon = GeburtsDatum.Month;
      int mdiff = mon - gmon;
      int jahr = DateTime.Today.Year;
      int gjahr = GeburtsDatum.Year;
      int mjahre = 12 * (jahr - gjahr);

      return this.GibMirDeinAlterInTagen() / 7;
    }


  }
}
