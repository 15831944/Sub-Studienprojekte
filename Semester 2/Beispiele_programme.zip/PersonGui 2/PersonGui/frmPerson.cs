﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PersonGui
{
  public partial class frmPerson : Form
  {
    Person mm_new;

    public frmPerson()
    {
      InitializeComponent();
      
    }


    private void btnOk_Click(object sender, EventArgs e)
    {
      //Person-Objekt erstellen
      mm_new = new Person();
      //Werte aus den Steuerelementen holen
      mm_new.Vorname = tbVorname.Text.ToString();
      mm_new.Name = tbName.Text.ToString();
      mm_new.GeburtsDatum = dtpGeburtstag.Value;
      Personen.instanz.Add(mm_new);


//      Personen.instanz.Hallo();
/*      

      //Person in Messagebox anzeigen
      this.mm_new.showMessagebox();*/
    }

    private void btnAbbrechen_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void dtpGeburtstag_ValueChanged(object sender, EventArgs e)
    {
      if (this.mm_new != null)
      {
        //Neues Datum setzen
        this.mm_new.GeburtsDatum = dtpGeburtstag.Value;
        //... und Label aktualisieren
        this.lblAlterInTagen.Text = "Du bist " + this.mm_new.GibMirDeinAlterInTagen() + " Tage alt!";
      }
    }


  }
}
