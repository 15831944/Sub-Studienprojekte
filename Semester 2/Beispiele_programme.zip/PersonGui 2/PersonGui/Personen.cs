﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PersonGui
{
  class Personen
  {
    List<Person> m_personenListe;

    #region singleton-Muster
    //privater Konstruktor
    private Personen()
    {
      m_personenListe = new List<Person>();
    }

    //privates statisches Objekt - das einzige Objekt
    private static Personen _instanz;

    //öffentlicher Lesezugriff auf das einzige Objekt
    public static Personen instanz
    {
      get
      {
        if (_instanz == null)
        {
          _instanz = new Personen();
        }
        return _instanz;
      }
    }

    #endregion

    public void Hallo()
    {
      MessageBox.Show("Hallo");
    }

    public int Add(string Name, string Vorname, DateTime Geburtsdatum)
    {
      Person xy = new Person();
      xy.Name = Name;
      xy.Vorname = Vorname;
      xy.GeburtsDatum = Geburtsdatum;
      m_personenListe.Add(xy);
      return m_personenListe.Count;
    }

    public int Add(Person xy)
    {
      m_personenListe.Add(xy);
      return m_personenListe.Count;
    }
      
    public int Add()
    {
      Person xy = new Person();
      m_personenListe.Add(xy);
      return m_personenListe.Count;
    }

    public Person item(int index)
    {
      return m_personenListe[index];
    }

  }
}
