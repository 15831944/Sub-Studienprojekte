﻿namespace PersonGui
{
  partial class frmPerson
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPerson));
      this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
      this.lblVorname = new System.Windows.Forms.Label();
      this.lblName = new System.Windows.Forms.Label();
      this.lblGeburtsdatum = new System.Windows.Forms.Label();
      this.dtpGeburtstag = new System.Windows.Forms.DateTimePicker();
      this.btnOk = new System.Windows.Forms.Button();
      this.btnAbbrechen = new System.Windows.Forms.Button();
      this.tbVorname = new PersonGui.myTextBox();
      this.tbName = new PersonGui.myTextBox();
      this.lblAlterInTagen = new System.Windows.Forms.Label();
      this.tableLayoutPanel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // tableLayoutPanel1
      // 
      this.tableLayoutPanel1.ColumnCount = 3;
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 95F));
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
      this.tableLayoutPanel1.Controls.Add(this.lblVorname, 0, 0);
      this.tableLayoutPanel1.Controls.Add(this.lblName, 0, 1);
      this.tableLayoutPanel1.Controls.Add(this.lblGeburtsdatum, 0, 2);
      this.tableLayoutPanel1.Controls.Add(this.dtpGeburtstag, 1, 2);
      this.tableLayoutPanel1.Controls.Add(this.btnOk, 2, 3);
      this.tableLayoutPanel1.Controls.Add(this.tbVorname, 1, 0);
      this.tableLayoutPanel1.Controls.Add(this.tbName, 1, 1);
      this.tableLayoutPanel1.Controls.Add(this.btnAbbrechen, 2, 2);
      this.tableLayoutPanel1.Controls.Add(this.lblAlterInTagen, 1, 3);
      this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
      this.tableLayoutPanel1.Name = "tableLayoutPanel1";
      this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(20);
      this.tableLayoutPanel1.RowCount = 5;
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
      this.tableLayoutPanel1.Size = new System.Drawing.Size(420, 139);
      this.tableLayoutPanel1.TabIndex = 0;
      // 
      // lblVorname
      // 
      this.lblVorname.AutoSize = true;
      this.lblVorname.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lblVorname.Location = new System.Drawing.Point(23, 20);
      this.lblVorname.Name = "lblVorname";
      this.lblVorname.Size = new System.Drawing.Size(89, 26);
      this.lblVorname.TabIndex = 0;
      this.lblVorname.Text = "Vorname";
      this.lblVorname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lblName.Location = new System.Drawing.Point(23, 46);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(89, 26);
      this.lblName.TabIndex = 1;
      this.lblName.Text = "Name";
      this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // lblGeburtsdatum
      // 
      this.lblGeburtsdatum.AutoSize = true;
      this.lblGeburtsdatum.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lblGeburtsdatum.Location = new System.Drawing.Point(23, 72);
      this.lblGeburtsdatum.Name = "lblGeburtsdatum";
      this.lblGeburtsdatum.Size = new System.Drawing.Size(89, 30);
      this.lblGeburtsdatum.TabIndex = 2;
      this.lblGeburtsdatum.Text = "Geburtsdatum";
      this.lblGeburtsdatum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // dtpGeburtstag
      // 
      this.dtpGeburtstag.Location = new System.Drawing.Point(118, 75);
      this.dtpGeburtstag.Name = "dtpGeburtstag";
      this.dtpGeburtstag.Size = new System.Drawing.Size(198, 20);
      this.dtpGeburtstag.TabIndex = 5;
      this.dtpGeburtstag.ValueChanged += new System.EventHandler(this.dtpGeburtstag_ValueChanged);
      // 
      // btnOk
      // 
      this.btnOk.Dock = System.Windows.Forms.DockStyle.Left;
      this.btnOk.Location = new System.Drawing.Point(322, 105);
      this.btnOk.Name = "btnOk";
      this.btnOk.Size = new System.Drawing.Size(75, 24);
      this.btnOk.TabIndex = 6;
      this.btnOk.Text = "Ok";
      this.btnOk.UseVisualStyleBackColor = true;
      this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
      // 
      // btnAbbrechen
      // 
      this.btnAbbrechen.Dock = System.Windows.Forms.DockStyle.Left;
      this.btnAbbrechen.Location = new System.Drawing.Point(322, 75);
      this.btnAbbrechen.Name = "btnAbbrechen";
      this.btnAbbrechen.Size = new System.Drawing.Size(75, 24);
      this.btnAbbrechen.TabIndex = 7;
      this.btnAbbrechen.Text = "Abbrechen";
      this.btnAbbrechen.UseVisualStyleBackColor = true;
      this.btnAbbrechen.Click += new System.EventHandler(this.btnAbbrechen_Click);
      // 
      // tbVorname
      // 
      this.tbVorname.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tbVorname.ForeColor = System.Drawing.Color.Gray;
      this.tbVorname.Location = new System.Drawing.Point(118, 23);
      this.tbVorname.Name = "tbVorname";
      this.tbVorname.Size = new System.Drawing.Size(198, 20);
      this.tbVorname.TabIndex = 8;
      this.tbVorname.VorgabeFarbe = System.Drawing.Color.Gray;
      this.tbVorname.Vorgabename = "Bitte den Vornamen eingeben";
      // 
      // tbName
      // 
      this.tbName.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tbName.ForeColor = System.Drawing.Color.Gray;
      this.tbName.Location = new System.Drawing.Point(118, 49);
      this.tbName.Name = "tbName";
      this.tbName.Size = new System.Drawing.Size(198, 20);
      this.tbName.TabIndex = 9;
      this.tbName.VorgabeFarbe = System.Drawing.Color.Gray;
      this.tbName.Vorgabename = "Bitte den Namen eingeben";
      // 
      // lblAlterInTagen
      // 
      this.lblAlterInTagen.AutoSize = true;
      this.lblAlterInTagen.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lblAlterInTagen.Location = new System.Drawing.Point(118, 102);
      this.lblAlterInTagen.Name = "lblAlterInTagen";
      this.lblAlterInTagen.Size = new System.Drawing.Size(198, 30);
      this.lblAlterInTagen.TabIndex = 10;
      this.lblAlterInTagen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmPerson
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(420, 139);
      this.Controls.Add(this.tableLayoutPanel1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPerson";
      this.Text = "Person bearbeiten";
      this.tableLayoutPanel1.ResumeLayout(false);
      this.tableLayoutPanel1.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    private System.Windows.Forms.Label lblVorname;
    private System.Windows.Forms.Label lblName;
    private System.Windows.Forms.Label lblGeburtsdatum;
    private System.Windows.Forms.DateTimePicker dtpGeburtstag;
    private System.Windows.Forms.Button btnOk;
    private System.Windows.Forms.Button btnAbbrechen;
    private myTextBox tbVorname;
    private myTextBox tbName;
    private System.Windows.Forms.Label lblAlterInTagen;
  }
}

