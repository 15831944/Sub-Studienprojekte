using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace Tastenbet�tigung_simulieren
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }


        // Tastenbet�tigungen k�nnen �ber SendKeys.Send oder .SendWait simuliert werden.
        // Zeichenfolge                     Bedeutung
        // +                                Shift-Taste
        // ^                                Strg-Taste
        // %                                Alt-Taste
        // {BACKSPACE}, {BS} oder {BKSP}    Backspace-Taste
        // {BREAK}                          Pause-Taste
        // {CAPSLOCK}                       Feststelltaste
        // {DELETE} oder {DEL}              L�sch-Taste (Entf)
        // {END}                            Ende-Taste
        // {ENTER} oder ~                   Return-(Enter-)Taste
        // {ESC}                            Escape-Taste (Esc)
        // {HELP}                           Hilfe-Taste (F1)
        // {HOME}                           Home-Taste (Pos1)
        // {INSERT} oder {INS}              Einf�gen-Taste (Einfg)
        // {NUMLOCK}                        Num-Lock-Taste
        // {PGDN}/{PGUP}                    Bild-nach-unten/oben-Taste
        // {PRTSC}                          Druck-Taste (f�r zuk�nftige Versionen reserviert)
        // {SCROLLLOCK}                     Rollen-Taste
        // {TAB}                            Tabulator-Taste
        // {UP}/{DOWN}/{LEFT}/{RIGHT}       Cursor-nach-oben/unten/links/rechts-Taste
        // {F1} ... {F16}                   Die Funktionstasten F1 bis F16
        // {ADD}                            Additionstaste auf der Zehnertastatur
        // {SUBTRACT}                       Subtraktionstaste auf der Zehnertastatur
        // {MULTIPLY}                       Multiplikationstaste auf der Zehnertastatur
        // {DIVIDE}                         Divisionstaste auf der Zehnertastatur

        private void demoButton_Click(object sender, EventArgs e)

        //using System.Threading erforderlich
        //public static void Main()
        {
            
            // Notepad starten
            Process.Start("Notepad");

            // Etwas warten, bis Notepad gestartet ist
            Thread.Sleep(500);

            // Einen kleinen Text schreiben
            SendKeys.SendWait("Das ist ein Text, der von .NET kommt");

            // STRG+S simulieren
            SendKeys.SendWait("^s");

            // �berpr�fen, ob die zu erzeugende Datei existiert, und
            // diese gegebenenfalls l�schen
            string filename = @"C:\SendKeys_Demo.txt";
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }

            // Dateinamen eingeben
            SendKeys.SendWait(filename);

            // Return simulieren
            SendKeys.SendWait("{ENTER}");

            // Notepad �ber ALT+F4 beenden
            SendKeys.SendWait("%{F4}");
        }
    }
}