﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace permutation_kopieren
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array_aufrauf = new int[] { 1, 2, 3, 4 };
            para(array_aufrauf, "");
            Console.ReadLine();
        }
        static void para(int[] folge, string vorganger)
        {
            if (folge.Length == 2)
            {//vorgange sind die zweite erste ziffer
                Console.WriteLine(vorganger + "" + folge[0] + folge[1]);
                Console.WriteLine(vorganger + "" + folge[1] + folge[0]);
            }
            else if (folge.Length > 2)
            {//i ist fur der vorgange
                for (int i = 0; i < folge.Length; i++)
                {

                    string newforganger = vorganger + folge[i];
                    int[] restfolge = new int[folge.Length - 1];
                    int h = 0;
                    for (int j = 0; j < folge.Length; j++)
                    {
                        //alle aussser des wert folge[i]kopieren

                        if (j != i)
                        {
                            restfolge[h] = folge[j];
                            h++;
                        }

                    }
                    //rekursion
                    para(restfolge, newforganger);
                }
            }

        }
    }
}
